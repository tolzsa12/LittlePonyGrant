<?php
    session_start();
    require_once 'config/db.php';

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="stylePaymentInCart.css">

    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />

    <script type="text/javascript" src="https://code.jquery.com/jquery-1.7.2.min.js"></script>
    <script type="text/javascript" scr="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <script type="text/javascript" src="mainJS.js"></script>

</head>

<body>

  <!--------------header-------->
    <header class="header" id="navigation-menu">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <a href="#" class="logo"> <img src="picture/logo.png" alt=""> </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav ">
                        <a class="nav-link active h5 ms-5 me-4" aria-current="page" href="HomePage.php">Home</a>
                        <a class="nav-link h5 me-4" href="#">About</a>
                        <a class="nav-link h5 me-4" href="Service1.php">Service</a>
                        <a class="nav-link h5 me-4" href="HomeRestaurant.php"">Restaurant</a>
                        <a class="nav-link h5 me-4" href="#"">Gallery</a>
                        <a class="nav-link h5 me-4" href="#"">Contact</a>
                    </div>
                    <div class="navbar-right ms-auto">
                        <a href="Totalcart1.php" class="cart"> <img src="picture/cart.png" alt=""> </a>
                        <a href="logout.php" class="btn btn-danger">Logout</a>
                    </div>
                    </div>
                </div>
            </nav>
        </div>
    </header>   

  <!--------------header-------->
<!--------------book-------------->
<!--section คือการแบ่งส่วนกัน---->
    <div class="home" id="home">
        <div class="head_container">
        <div class="image">
            <img src="picture/home1.png" class="slide">
        </div>
        </div>
    </div>


    <!--book_detail-->
    <div class="book_detail">

        <div class="row"><!--for flexing-->

            <form method= "post" action = "">
                <input type="hidden" name="UserID" id="UserID" value =" <?php echo $_SESSION['UserID']; ?> ">

                <div class="section-input">
                    <div class="part-input">  
                        <ul class="input">  
                            <div class="main_box">
                                <br><h4 style="text-align: center; margin-top: 15%;">Guest Information</h4>

                                    <div class="inputBx">
                                        <label for="GuestName">Guest name</label>
                                        <input calss="GuestName" id="GuestName" type="text" name="GuestName" placeholder="Guest Name" require>
                                    </div>
                                    <div class="inputBx">
                                        <label for="Phone_Guest">Phone Number</label>
                                        <input calss="Phone_Guest" id="Phone_Guest" type="text" name="Phone_Guest" placeholder="Phone Number" require>
                                    </div>
                                    <div class="inputBx">
                                        <label for="Message">Notify to hotel</label>
                                        <input calss="Message" id="Message" type="text" name="Message" placeholder="Enter your message" require>
                                    </div>

                            </div>
                        </ul>
                    </div>
                    <div class="end_line"></div>


                    <?php
                        if(isset($_POST["booking"]))
                            {
                                if(isset($_SESSION["shopping_cart"]))
                                {
                                $totalprice = 0;
                                $totaltax = 0;
                                    foreach($_SESSION["shopping_cart"] as $keys=>$values)
                                    {
                            
                                        if($values["date_checkout"]=="")
                                        {
                                            $check_in_date = $values["date_checkin"];
                                            $minutes_to_add = 120;
                                            $time = new DateTime("$check_in_date");
                                            $time->add(new DateInterval('PT' . $minutes_to_add . 'M'));
                                            
                                            $stamp = $time->format('Y-m-d H:i');
                                            
                                        }
                                        else
                                        {
                                            $check_out = $values["date_checkout"];
                                            
                                        }
                                        
                                        $totalprice = $totalprice + ($values["item_price"]+$values["item_tax"]);
                                        $totaltax = $totaltax + $values["item_tax"];
                                    }
                                    
                                }
                            }
                        else{ echo "";}
                        ?>




                    <div class="Payment_method">
                        <h2 style="margin-top: 1%;">Payment and Confirmation</h2>
                        <div class="Payment_Box">
                            <div class="inputBx">
                                <label for="type_payment_method">Type payment</label>
                                    <select class="form-control" id="PaymentMethod_ID" name="PaymentMethod_ID" data-error="Select ID Card Type" required>
                                        <option selected disabled>Select ID Card Type</option>
                                            <?php
                                                $sql = mysqli_query($conn,"SELECT * FROM payment_method ORDER BY PaymentMethod_Name");
                                                while ($row = mysqli_fetch_array($sql)) {
                                                    ?>
                                                    <option value="<?php echo $row['PaymentMethod_ID'];?>"><?php echo $row['PaymentMethod_Name'];?></option>
                                                    <?php
                                                }
                                            ?>

                                    </select>
                            </div>

                            <div class="inputBx">
                                <label for="card_number">Card number</label>
                                <input id="card_number" type="text" name="card_number" placeholder="Card number" require>
                            </div>
                            <div class="Button_summit"> 
                                <input type="submit" name = "finish_booking"value="Finish Booking">
                                </form>
                            </div>    
                        </div>    
                    </div>
            </form>

            <?php
                if(isset($_POST["finish_booking"]))
                {
                    if(isset($_SESSION["shopping_cart"]))
                        {
                            $totalprice = 0;
                            $totaltax = 0;
                                foreach($_SESSION["shopping_cart"] as $keys=>$values)
                                {
                                    $totalprice = $totalprice + ($values["item_price"]+$values["item_tax"]);
                                    $totaltax = $totaltax + $values["item_tax"];
                                }
                                //echo "<br>total price is" .$totalprice;
                                //echo "<br>total tax is" .$totaltax;
                                    
                                //$UserID กำหนดให้เป็น 999
                                $final_price =  $totalprice;
                                $PaymentMethod_ID = $_POST['PaymentMethod_ID'];
                                $CardNumber = $_POST['card_number'];
                                $TaxandFee = $totaltax;
                                $GuestName = $_POST['GuestName'] ;
                                $Phone_Guest = $_POST['Phone_Guest'];
                                $Message =$_POST['Message'];
                                $UserID = $_POST['UserID'];
                                $main_reference_number_sql = "INSERT INTO main_reference_number (UserID,PriceTotalPayment,PaymentMethod_ID,CardNumber,TaxandFee,GuestName,Phone_Guest,Message) VALUES ('$UserID','$final_price','$PaymentMethod_ID','$CardNumber','$TaxandFee','$GuestName','$Phone_Guest','$Message')";

                                $main_reference_number_result = mysqli_query($conn, $main_reference_number_sql);
                                        
                                if(isset($_POST["finish_booking"]))
                                {   
                                    if(isset($_SESSION["shopping_cart"]))
                                    {
                                        $ReferenceNumber = mysqli_insert_id($conn);
                                        foreach($_SESSION["shopping_cart"] as $keys=>$values)
                                        {
                                            $room_no = $values["item_name"];
                                
                                            $MemberGuest = $values["member_guest"];
                                    
                                            //$stamp คือเวลาเช็คอินที่มีการแปลงแล้ว
                                            
                                            // $check_in_date = $values['date_checkin'];
                                            //$check_out_date = $values['date_checkout'];
                                            if($values["date_checkout"]=="")
                                                {
                                                    $stamp1 = $values["date_checkin"];
                                                    $minutes_to_add = 120;
                                                    $time = new DateTime("$stamp1");
                                                    $time->add(new DateInterval('PT' . $minutes_to_add . 'M'));
                                                    $stamp2 = $time->format('Y-m-d H:i:s');
                                                    // $stamp2 = $time->
                                                    //  echo" ".$stamp1." ".$stamp2;
                                                }
                                                else //Clear แล้ว
                                                {
                                                    $check_in = $values["date_checkin"];
                                                    $check_out = $values["date_checkout"];
                                                    $minutes_to_add = 720;
                                                    $time = new DateTime($check_in);
                                                    $time->add(new DateInterval('PT' . $minutes_to_add . 'M'));
                                                    $stamp1 = $time->format('Y-m-d H:i');
                                                    
                                                    $time = new DateTime($check_out);
                                                    $time->add(new DateInterval('PT' . $minutes_to_add . 'M'));
                                                    $stamp2 = $time->format('Y-m-d H:i');
                                                    // echo "Finally ".$check_out;
                                                }
                                                // echo "check_in_date is ".$check_in_date. " check_out_date is".$check_out_date;
                                                    //echo "<br>";
                                                // $time = new DateTime($check_in_date);
                                                // $time->add(new DateInterval('PT' . $minutes_to_add . 'H'));
                                                // $stamp = $time->format('Y-m-d H:i');
                                                    //$stamp2 คือเวลาเช็คเอ้าที่มีการแปลงแล้ว 
                                                    //Gen referenceNumber หลังจากที่ใส่ใน main เรียบร้อยแล้ว
                                            $partial_reference_number_sql = "INSERT INTO partial_reference_number (Reference_PartialNumber,ReferenceNumber,Booking_ID,MemberGuest,CheckInDateTime,CheckOutDateTime,Staff_ID) VALUES ('','$ReferenceNumber','$room_no','$MemberGuest','$stamp1','$stamp2','100001')";
                                            $partial_reference_number_result = mysqli_query($conn, $partial_reference_number_sql);
                                        }
                                        echo '<script>alert("Already Add in the database, please Check your database")</script>';
                                        unset($_SESSION["shopping_cart"]);
                                        // echo '<script>window.location="payment2.php"</script>';
                                    }
                                    
                                }

                            //finalprice คืออันที่รวม tax / $taxandFee เอาจากตารางที่แล้วได้
                            //Cardnumber / Guestname / message /type payment,phone guestกรอกจากหน้านี้
                            //User ID เราสมมุติเอาเลย โรสเอาจากการล้อกอิน
                
                        }
                }

            ?>


        </div>
    </div>




