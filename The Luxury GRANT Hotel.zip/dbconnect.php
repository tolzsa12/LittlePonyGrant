<?php

$con=mysqli_connect("localhost","root","","a4_grant") or die("เกิดข้อผิดพลาด");

//echo "เชื่อมต่อสำเร็จ";
?>