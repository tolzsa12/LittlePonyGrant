<?php
require_once 'config/db.php';

$PromotionID = $_GET["PromotionID"];
$sql = "DELETE FROM list_promotion WHERE PromotionID = $PromotionID";
$result = mysqli_query($conn,$sql);

if($result){
    header("location:ManagerPromotion.php");
    exit(0);
}else{
    echo "ไม่สามารถลบได้ มีข้อผิดพลาดเกิดขึ้น";
}
?>