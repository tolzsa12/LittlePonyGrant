<?php 

    session_start();
    require_once 'config/db.php';

    //$Staff_ID = $_GET['StaffID'];

    if (isset($_POST['upload_promotion'])) {
        $PromotionID = $_POST['PromotionID'];
        $Booking_ID = $_POST['Booking_ID'];
        $Standard_Price = $_POST['Standard_Price'];
        $PromotionPrice = $_POST['PromotionPrice'];
        $StartPromotion = $_POST['StartPromotion'];
        $DuedatePromotion = $_POST['DuedatePromotion'];


        $stmt = "UPDATE list_promotion SET PromotionID = '$PromotionID', 
        Booking_ID = '$Booking_ID', Standard_Price = '$Standard_Price', PromotionPrice ='$PromotionPrice', StartPromotion='$StartPromotion', DuedatePromotion='$DuedatePromotion'
        WHERE PromotionID = $PromotionID";    
    
        
        $result = mysqli_query($conn,$stmt);

        if ($result) {
            header("location: ManagerPromotion.php");
        }else {
            $_SESSION['error'] = "Something went wrong";
            header("location: update_promotion.php?PromotionID= $PromotionID");
            exit();
        }

    }
?>