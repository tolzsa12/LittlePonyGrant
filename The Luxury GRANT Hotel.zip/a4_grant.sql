-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2022 at 01:35 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `a4_grant`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_status_for_staff`
--

CREATE TABLE `data_status_for_staff` (
  `Status_Staff_ID` varchar(3) NOT NULL,
  `Status_Staff_Name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `data_status_for_staff`
--

INSERT INTO `data_status_for_staff` (`Status_Staff_ID`, `Status_Staff_Name`) VALUES
('100', 'unavailable'),
('101', 'available');

-- --------------------------------------------------------

--
-- Table structure for table `data_status_of_booking`
--

CREATE TABLE `data_status_of_booking` (
  `Status_Booking_ID` varchar(3) NOT NULL,
  `Status_Booking_Name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `data_status_of_booking`
--

INSERT INTO `data_status_of_booking` (`Status_Booking_ID`, `Status_Booking_Name`) VALUES
('200', 'booked, haven\'t checked in'),
('202', 'checked-in'),
('222', 'available');

-- --------------------------------------------------------

--
-- Table structure for table `hotel`
--

CREATE TABLE `hotel` (
  `BranchHotel_ID` varchar(4) NOT NULL,
  `HotelName` varchar(255) NOT NULL,
  `Hotel_Address` text NOT NULL,
  `City` varchar(30) NOT NULL,
  `Postcode` varchar(5) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `HotelPhone` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `hotel`
--

INSERT INTO `hotel` (`BranchHotel_ID`, `HotelName`, `Hotel_Address`, `City`, `Postcode`, `Email`, `HotelPhone`) VALUES
('BR01', 'The GRANT Luxury Hotels Krabi', '277 หมู่ที่ 5 Muang Pattaya, Bang Lamung District ,Mueang Krabi', 'Krabi', '81120', 'thegrantluxuryhotels.kb@gmail.com', '02-305-611'),
('BR02', 'The GRANT Luxury Hotels Satun', '454 Damnoen Kasem Road, Hua Hin, Mueang Satun', 'Satun', '91130', 'thegrantluxuryhotels.st@gmail.com', '02-113-233'),
('BR03', 'The GRANT Luxury Hotels Prachuap Khiri Khan', '683 Karon Beach, Patak Rd, Karon, Mueang Prachuap Khiri Khan', 'Prachuap Khiri Khan', '77110', 'thegrantluxuryhotels.pk@gmail.com', '02-191-334');

-- --------------------------------------------------------

--
-- Table structure for table `list_booking`
--

CREATE TABLE `list_booking` (
  `Booking_ID` int(6) NOT NULL,
  `Partial_Type_Booking_ID` int(4) NOT NULL,
  `Booking_Name` text NOT NULL,
  `TotalMember` int(11) NOT NULL,
  `Status_Booking_ID` varchar(3) NOT NULL,
  `BranchHotel_ID` varchar(4) NOT NULL,
  `Description` text NOT NULL,
  `Picture` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `list_booking`
--

INSERT INTO `list_booking` (`Booking_ID`, `Partial_Type_Booking_ID`, `Booking_Name`, `TotalMember`, `Status_Booking_ID`, `BranchHotel_ID`, `Description`, `Picture`) VALUES
(1, 3, 'Funebenri', 1, '222', 'BR01', 'The boat can accommodate a maximum of 25 people. Diving, photography, and fishing services are available.Price includes softdrink, fruit, fishing equipment, life jackets, plates, bowls, cutlery, forks,\nPetrol, captain, crew attendant, paddle board', 'https://cdn.glitch.global/2168daf6-7d4e-4323-a1b9-f7bc26985a0c/boat3.png?v=1650983844171'),
(2, 3, 'Chataeu', 1, '202', 'BR01', 'The 63 ft boat can accommodate 35 customers.Diving, photography, and fishing services are available. Price includes soft drink , fruit , snorkeling equipment,\nFishing equipment, life jackets, plates, bowls, spoons, forks,\nice , oil , captain , cabin attendant', 'https://cdn.glitch.global/2168daf6-7d4e-4323-a1b9-f7bc26985a0c/boat2.png?v=1650983841126'),
(3, 3, 'Crociera', 1, '222', 'BR02', 'The 63 ft boat can accommodate 50 customers.Diving, photography, and fishing services are available. Price includes \nDrinking water, ice, tea, coffee, fruit , snorkeling equipment,\nFishing equipment, life jackets, plates, bowls, spoons, forks,\nPetrol, captain, boat attendant, slide\n2 broad stands', 'https://cdn.glitch.global/f2207cfd-db48-4054-a818-6fd8a14d4988/boat.png?v=1650902533283'),
(4, 2, 'Mazda CX-30 2.0 C', 1, '200', 'BR01', 'Gear Auto 6AT (SkyAtctiv-Drive) 4 seats Electrical System', 'https://cdn.glitch.global/f48bbd74-564d-420c-bf5a-575f57931ddd/car1.png?v=1650982292474'),
(5, 2, 'Nissan Note', 1, '202', 'BR01', 'Gear Auto , 8 seats Electrical System 5-door hatchback resistive touchscreen and GPS receiver', 'https://th.bing.com/th/id/R.361835f5a5d35cf23c0781500052a201?rik=OVRs1qywk3rPAg&pid=ImgRaw&r=0'),
(6, 2, 'MG3', 1, '222', 'BR01', 'Gear Auto 4 speed(Manual mode) 4 seats Electrical System', 'https://th.bing.com/th/id/R.b25745ddd5e486c35934495732fce700?rik=cFbQMntU%2fzFdww&pid=ImgRaw&r=0'),
(7, 2, 'Sabaru XV 2.0i-P EyeSight', 1, '200', 'BR01', 'Gear Auto CVT (Lineartronic) 4 seats Electrical System', 'https://cdn.glitch.global/f48bbd74-564d-420c-bf5a-575f57931ddd/car2.png?v=1650982293892'),
(8, 2, 'Lexus LM300', 1, '202', 'BR02', 'Gear Auto , 8 seats Electrical System resistive touchscreen and GPS receiver', 'https://th.bing.com/th/id/R.219dd0631f9a029dca19932bf2b3bb76?rik=4k3r8NYMC2dLHA&pid=ImgRaw&r=0'),
(9, 2, 'Toyota Yaris', 1, '200', 'BR01', 'Gear Auto , 5 seats Electrical System resistive touchscreen and GPS receiver', 'https://th.bing.com/th/id/R.e946abacf512d6a597aacdeffa81150e?rik=i%2bjOxFUTkt4fQQ&pid=ImgRaw&r=0'),
(10, 2, 'Porsche 918 Spyder', 1, '200', 'BR01', 'Gear Auto, hypercar ,7-speed PDK dual-clutc, 2 seats , 2-door Targa top roadster (Spyder) , Electrical System', 'https://th.bing.com/th/id/R.fbe2741d321033f4cea35e7f1ed700ea?rik=6oaAyomfL0qOFQ&riu=http%3a%2f%2fwww.ausmotive.com%2fimages2%2fPorsche-918-Spyder-02.jpg&ehk=88ldFAXO7bTtXcZplMBbPBRRKKZF877cYmGI6tTu%2bX0%3d&risl=&pid=ImgRaw&r=0'),
(11, 2, 'Nissan Note', 1, '202', 'BR01', 'Gear Auto , 8 seats Electrical System 5-door hatchback resistive touchscreen and GPS receiver', 'https://th.bing.com/th/id/R.361835f5a5d35cf23c0781500052a201?rik=OVRs1qywk3rPAg&pid=ImgRaw&r=0'),
(12, 2, 'McLaren P1', 1, '222', 'BR01', 'Gear Auto , 2 seats 7-speed dual-clutch, 1 McLaren E-Motor, Sports car', 'https://th.bing.com/th/id/R.3572c9f44a0947e17e549ae6d5c88d41?rik=F8mjdO4wm7XQ0A&pid=ImgRaw&r=0'),
(13, 2, 'Lexus LM300', 1, '222', 'BR01', 'Gear Auto , 8 seats Electrical System resistive touchscreen and GPS receiver', 'https://th.bing.com/th/id/R.219dd0631f9a029dca19932bf2b3bb76?rik=4k3r8NYMC2dLHA&pid=ImgRaw&r=0'),
(14, 4, 'Towerlounge Dinner 1', 1, '202', 'BR01', 'Starter, steamed egg custard, sashimi, main dish, fried garlic rice with miso soup and pickles, and dessert', 'https://th.bing.com/th/id/OIP.uzLK3OKvhohBRhkmRuPeTQHaE7?pid=ImgDet&rs=1'),
(15, 4, 'Yamazato Dinner 1', 1, '222', 'BR01', 'Appetizer, soup, sashimi, grilled dish, simmered dish, rice dish, and dessert 　', 'https://cdn.glitch.global/a7257ba0-d650-4b1b-a20e-64cbaa250ed2/food1.png?v=1650988418305'),
(16, 4, 'Thaifood set', 1, '200', 'BR01', 'Satsuma black cattle sirloin and foie gras with balsamic sauce and yuzu miso', 'https://www.twinpalmshotelsresorts.com/wp-content/uploads/2019/09/4024-1024x683.jpg'),
(17, 4, 'Towerlounge Dinner 2', 1, '202', 'BR01', 'Starter, steamed egg custard, grilled fish, tempura, assorted sushi with miso soup, and dessert', 'https://cdn.glitch.global/a7257ba0-d650-4b1b-a20e-64cbaa250ed2/food2.png?v=1650988432927'),
(18, 4, 'Salmon Set & Seafood', 1, '222', 'BR01', 'Satsuma black cattle sirloin and foie gras with balsamic sauce and yuzu miso', 'https://images.thaiza.com/content/b/415429.jpg'),
(19, 4, 'Yamazato Dinner 2', 1, '222', 'BR01', 'Appetizer, grilled dish, tempura, nigiri sushi (8 pieces and 3 sushi rolls), soup, and dessert', 'https://cdn.glitch.global/a7257ba0-d650-4b1b-a20e-64cbaa250ed2/food2.png?v=1650988432927'),
(20, 4, 'Yamazato Dinner 3', 1, '222', 'BR01', 'Appetizer, soup, sashimi, grilled dish, simmered dish, rice dish, and dessert 　', 'https://cdn.glitch.global/a7257ba0-d650-4b1b-a20e-64cbaa250ed2/food3.png?v=1650982392094'),
(21, 4, 'Chinesefood set', 1, '222', 'BR01', 'Appetizer, sashimi, salad with crab, wagyu beef A4-grade tenderloin100g or sirloin 150g \nrice and miso soup, and dessert', 'https://i0.wp.com/www.xn--o3cdbr1ab9cle2ccb9c8gta3ivab.com/wp-content/uploads/2019/09/chinese-food.jpg?ssl=1'),
(22, 1, 'Thai Herbal Steam', 1, '222', 'BR01', 'Thai Herbal Steam Sauna is a treatment which uses steaming with herbs. It is believed to soften the skin, helps cleanse body impurities and relax the muscles. The treatment is usually followed by a cold plunge or shower to restimulate the whole body.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/steam420-2.jpg'),
(23, 1, 'Dream Package', 1, '200', 'BR01', 'A quick reward for the day for guests who wanted to experience the art of reflexology and stimulating pressure points under a limited time. This series of treatments at our Thai spa and massage locations helps with body circulation, relieves stress, and reinvigorates the body for days to come. A dream package includes a 45-minutes Foot Reflexology, a 15-minutes Hand Reflexology, and a 30-minutes Back and Shoulder Massage.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/dream420.gif'),
(24, 1, 'Foot Reflexology', 1, '222', 'BR01', 'This popular massage lets you sit and relax after a long day of traveling. Not only it helps relieve the tension in the lower parts of the leg, this ancient massage is believed to help promote oxygenation of tissues of several major organs of the body by focusing on the reflex zones of the feet that correspond to them. Other benefits include improved circulation, ease of pain and treatment of ranges of acute and chronic illnesses.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/FT2.jpg'),
(25, 1, 'Golfer\'s Heaven', 1, '200', 'BR01', 'This package is a perfect combination of all kinds of exercise that involves the movement of the legs. The 45-minute Foot Reflexology massage relieves the tensions in the lower parts of the leg as well as promotes circulation. The 90-minutes Hot Stone Massage goes further into the deep tissue level of the whole body', 'https://letsrelaxspa.com/wp-content/uploads/2017/10/golfer420.gif'),
(26, 1, 'Golfer\'s Heaven', 1, '202', 'BR01', 'This package is a perfect combination of all kinds of exercise that involves the movement of the legs. The 45-minute Foot Reflexology massage relieves the tensions in the lower parts of the leg as well as promotes circulation. The 90-minutes Hot Stone Massage goes further into the deep tissue level of the whole body', 'https://letsrelaxspa.com/wp-content/uploads/2017/10/golfer420.gif'),
(27, 1, 'Back & Shoulder', 1, '200', 'BR03', 'This massage technique utilizes finger pressure along with the hands and elbows on tension areas of back and shoulder. Guests get to sits on a specially designed massage chair that gives full comfort after the massage. The treatment is good for jet lags, eases strain and tension, mobilizes stiff joints, and improves blood circulation. A great treat after a long day of office work.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/bsd-2.jpg'),
(28, 1, 'Back & Shoulder', 1, '200', 'BR01', 'This massage technique utilizes finger pressure along with the hands and elbows on tension areas of back and shoulder. Guests get to sits on a specially designed massage chair that gives full comfort after the massage. The treatment is good for jet lags, eases strain and tension, mobilizes stiff joints, and improves blood circulation. A great treat after a long day of office work.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/bsd-2.jpg'),
(29, 1, 'Floral Bath', 1, '202', 'BR03', 'Perfect your spa experience at The GRANT Luxury Spa with a private time in the whirlpool bath sprinkled with tropical flower petals after your treatments. A great way to pamper and ready yourself for days to come.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/floral420-2.jpg'),
(30, 1, 'Floral Bath', 1, '222', 'BR01', 'Perfect your spa experience at The GRANT Luxury Spa with a private time in the whirlpool bath sprinkled with tropical flower petals after your treatments. A great way to pamper and ready yourself for days to come.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/floral420-2.jpg'),
(31, 1, 'Aromatherapy Oil Massage', 1, '200', 'BR01', 'This is a favorite at all of our Thai massage and spa locations. It uses an ancient therapeutic method of pressure point massage utilizing essential oils from plants, leaves, and flowers that are applied to the body with a Swedish massage technique. A good treatment to reward yourself after a long day of work or travel, the treatment is found to stimulate blood flow and lymph fluid.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/warmoil420-2.jpg'),
(32, 1, 'Aromatherapy Oil Massage', 1, '202', 'BR01', 'This is a favorite at all of our Thai massage and spa locations. It uses an ancient therapeutic method of pressure point massage utilizing essential oils from plants, leaves, and flowers that are applied to the body with a Swedish massage technique. A good treatment to reward yourself after a long day of work or travel, the treatment is found to stimulate blood flow and lymph fluid.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/warmoil420-2.jpg'),
(33, 1, 'Aromatic Hot Stone Massage', 1, '222', 'BR01', 'Reach the height of relaxation with our aromatic hot stone massage, where a combination of heated volcanic stones and warm massage oils are applied to massage the whole body at the deep muscle level. This signature treatment is found to release tension, promote circulation, combat nervous fatigue and create a positive energy flow in the body. This hot stone massage is an experience that everyone should try.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/hot-stone420-2.jpg'),
(34, 1, 'Aromatic Hot Stone Massage', 1, '200', 'BR01', 'Reach the height of relaxation with our aromatic hot stone massage, where a combination of heated volcanic stones and warm massage oils are applied to massage the whole body at the deep muscle level. This signature treatment is found to release tension, promote circulation, combat nervous fatigue and create a positive energy flow in the body. This hot stone massage is an experience that everyone should try.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/hot-stone420-2.jpg'),
(35, 1, 'Spa Experience (Dr.Spiller)', 1, '202', 'BR01', 'A half-day of fun with an unparalleled spa experience. Start your day with a 60-minute body wrap or body scrub followed by a 60-minute Dr.Spiller Pure SkinCare Solutions 10-step facial soothing massage treatment. Then she finishes with a 90 minute aromatic hot stone massage. By activating the skin, face, and deep muscle tissue leaves, you feel like you have a fresh, new body.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/experience420.gif'),
(36, 1, 'Spa Experience (Dr.Spiller)', 1, '222', 'BR01', 'A half-day of fun with an unparalleled spa experience. Start your day with a 60-minute body wrap or body scrub followed by a 60-minute Dr.Spiller Pure SkinCare Solutions 10-step facial soothing massage treatment. Then she finishes with a 90 minute aromatic hot stone massage. By activating the skin, face, and deep muscle tissue leaves, you feel like you have a fresh, new body.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/experience420.gif'),
(37, 1, 'Four hands Thai massage', 1, '222', 'BR01', 'Traditional Thai massage is performed at our Thai massage and spa facility by two therapists at once. It involves a unique combination of gentle stretching and acupressure techniques. The oil-free massage is performed on a mattress, while loose pajamas are worn. Guests usually say that the experience is superior to a regular Thai massage. Another must-try at The GRANT Luxury Spa.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/fourhand420-2.jpg'),
(38, 1, 'Four hands Thai massage', 1, '202', 'BR01', 'Traditional Thai massage is performed at our Thai massage and spa facility by two therapists at once. It involves a unique combination of gentle stretching and acupressure techniques. The oil-free massage is performed on a mattress, while loose pajamas are worn. Guests usually say that the experience is superior to a regular Thai massage. Another must-try at The GRANT Luxury Spa.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/fourhand420-2.jpg'),
(39, 1, 'Onsen', 1, '222', 'BR01', 'The GRANT Luxury Onsen and Spa, Bangkok, provides hot baths enriched with powerful luxurious minerals imported from Gero spring, Japan, that continuously protect, heal, and rejuvenate the body at the cellular level. This will keep the body and mind healthy, rejuvenated, refreshed, relaxed and clean. Guests also have full-day access to enjoy other facilities such as sauna, steam, warm Himalayan Hot Stonebed Baths , and Cool Down Rooms. Feel the rejuvenating effects of the best Japanese bath in Bangkok at Let’s Relax Onsen and Spa Thonglor.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/ONSEN3.jpg'),
(40, 1, 'Onsen', 1, '200', 'BR01', 'The GRANT Luxury Onsen and Spa, Bangkok, provides hot baths enriched with powerful luxurious minerals imported from Gero spring, Japan, that continuously protect, heal, and rejuvenate the body at the cellular level. This will keep the body and mind healthy, rejuvenated, refreshed, relaxed and clean. Guests also have full-day access to enjoy other facilities such as sauna, steam, warm Himalayan Hot Stonebed Baths , and Cool Down Rooms. Feel the rejuvenating effects of the best Japanese bath in Bangkok at Let’s Relax Onsen and Spa Thonglor.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/ONSEN3.jpg'),
(41, 1, 'Body & Soul', 1, '202', 'BR01', 'With the Body & Soul Package, our guest chooses between a 60-minutes Body Scrub or Body Wrap, followed by 60-minutes of Aromatherapy oil massage. The former treatments improve the skin moisture or renewal, while the aromatic oil treatment provides ultimate relaxation and skin protection. It’s a classic combination for a full-body pampering at our spa.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/bodysoul420.gif'),
(42, 1, 'Body & Soul', 1, '222', 'BR03', 'With the Body & Soul Package, our guest chooses between a 60-minutes Body Scrub or Body Wrap, followed by 60-minutes of Aromatherapy oil massage. The former treatments improve the skin moisture or renewal, while the aromatic oil treatment provides ultimate relaxation and skin protection. It’s a classic combination for a full-body pampering at our spa.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/bodysoul420.gif'),
(43, 1, 'Body Scrub', 1, '200', 'BR01', 'This spa treatment exfoliates the dead skin cells using various combination of sea salt, essential oils, water, skin brush, or loofah. Guest can choose from the selection of 6 types of scrub that best suited with their type of skin. The treatment is found to nourish the skin, improve circulation, cleanse and tone even the most sensitive skin.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/scrub420-2.jpg'),
(44, 1, 'Body Scrub', 1, '202', 'BR01', 'This spa treatment exfoliates the dead skin cells using various combination of sea salt, essential oils, water, skin brush, or loofah. Guest can choose from the selection of 6 types of scrub that best suited with their type of skin. The treatment is found to nourish the skin, improve circulation, cleanse and tone even the most sensitive skin.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/scrub420-2.jpg'),
(45, 1, 'Body Wrap', 1, '222', 'BR01', 'Treatment where the body is pasted with herb and wrapped in a plastic sheet and kept under the heated blankets for about 20 minutes, allowing the skin to be pampered and moisturized. You can choose between cool aloe vera wrap, a perfect treatment after a long day under the sun, or warm wrap for extra moisturization of the skin', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/wrap420-2.jpg'),
(46, 1, 'Body Wrap', 1, '202', 'BR01', 'Treatment where the body is pasted with herb and wrapped in a plastic sheet and kept under the heated blankets for about 20 minutes, allowing the skin to be pampered and moisturized. You can choose between cool aloe vera wrap, a perfect treatment after a long day under the sun, or warm wrap for extra moisturization of the skin', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/wrap420-2.jpg'),
(47, 1, 'Full Spirit', 1, '222', 'BR02', 'Similar to Body & Soul Package, the Full Spirit package lets our guest relax and revitalize the skin with 60 minutes of Body Scrub or Body Wrap, and a 60-minutes Aromatherapy Oil Massage. However, with Full Spirit package, the added 45-minutes Foot Reflexology lets the guest heals beyond the skin, to the invigoration inner body.', 'https://letsrelaxspa.com/wp-content/uploads/2017/08/full420.gif'),
(48, 5, 'DE01 Deluxe Room', 2, '200', 'BR03', 'Standard room, size 85 square meters, consists of queen size bed, can accommodate 2 adults, a bathroom with a shower, free Wi-Fi, kitchen equipment and beverages in the room. and sea view rooms', 'https://cdn.glitch.global/f2207cfd-db48-4054-a818-6fd8a14d4988/1003.png?v=1650902532014'),
(49, 5, 'DE02 Deluxe Room', 2, '200', 'BR01', 'Standard room, size 85 square meters, consists of queen size bed, can accommodate 2 adults, a bathroom with a shower, free Wi-Fi, kitchen equipment and beverages in the room. and sea view rooms', 'https://cdn.glitch.global/f2207cfd-db48-4054-a818-6fd8a14d4988/room5.png?v=1650902538801'),
(50, 6, 'DO01 Duo Room', 2, '222', 'BR01', 'Standard room, size 85 square meters, consists of couple bed size 3.5 ft. , can accommodate 2 adults, a bathroom with a shower, free Wi-Fi, kitchen equipment and beverages in the room. and sea view rooms', 'https://cdn.glitch.global/f2207cfd-db48-4054-a818-6fd8a14d4988/2003.jfif?v=1650902530283'),
(51, 6, 'DO02 Duo Room', 2, '200', 'BR01', 'Standard room, size 85 square meters, consists of couple bed size 3.5 ft. , can accommodate 2 adults, a bathroom with a shower, free Wi-Fi, kitchen equipment and beverages in the room. and sea view rooms', 'https://cdn.glitch.global/f2207cfd-db48-4054-a818-6fd8a14d4988/2002.jfif?v=1650902536704'),
(52, 7, 'SU01 Suite Room', 3, '200', 'BR01', 'Suite room, size 156 square meters, consists of 2 bedroom and 2 bathroom. 1 king size bed and 1 queen size bed, can accommodate 5 adults, a bathroom with a shower and bathtub, free Wi-Fi, kitchen equipment and beverages in the room. Sea view rooms.', 'https://cdn.glitch.global/f2207cfd-db48-4054-a818-6fd8a14d4988/3003.jfif?v=1650902531575'),
(53, 7, 'SU02 Suite Room', 3, '222', 'BR01', 'Suite room, size 156 square meters, consists of 2 bedroom and 2 bathroom. 1 king size bed and 1 queen size bed, can accommodate 5 adults, a bathroom with a shower and bathtub, free Wi-Fi, kitchen equipment and beverages in the room. Sea view rooms.', 'https://cdn.glitch.global/f2207cfd-db48-4054-a818-6fd8a14d4988/3002.jfif?v=1650902531341'),
(54, 8, 'LX01 Luxury sky Room', 5, '200', 'BR01', 'Luxury sky room are large room size 225 square meters, consists of 3 bedroom and 3 bathroom. 3 king size bed , can accommodate 7 person, a bathroom with a shower and bathtub, free Wi-Fi, kitchen equipment and beverages in the room. Sea view rooms.', 'https://cdn.glitch.global/f2207cfd-db48-4054-a818-6fd8a14d4988/4003.jfif?v=1650902533183'),
(55, 8, 'LX02 Luxury sky Room', 5, '200', 'BR02', 'Luxury sky room are large room size 225 square meters, consists of 3 bedroom and 3 bathroom. 3 king size bed , can accommodate 7 person, a bathroom with a shower and bathtub, free Wi-Fi, kitchen equipment and beverages in the room. Sea view rooms.', 'https://cdn.glitch.global/f2207cfd-db48-4054-a818-6fd8a14d4988/4002.png?v=1650902540784');

-- --------------------------------------------------------

--
-- Table structure for table `list_promotion`
--

CREATE TABLE `list_promotion` (
  `PromotionID` int(5) NOT NULL,
  `Booking_ID` int(6) NOT NULL,
  `Standard_Price` double NOT NULL,
  `PromotionPrice` double NOT NULL,
  `StartPromotion` date NOT NULL,
  `DuedatePromotion` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `list_promotion`
--

INSERT INTO `list_promotion` (`PromotionID`, `Booking_ID`, `Standard_Price`, `PromotionPrice`, `StartPromotion`, `DuedatePromotion`) VALUES
(1, 1, 15000, 13900, '2022-01-01', '2022-04-30'),
(2, 1, 15000, 11750, '2022-05-01', '2022-08-31'),
(3, 1, 15000, 12250, '2022-09-01', '2022-12-31'),
(4, 2, 20000, 18000, '2022-01-01', '2022-04-30'),
(5, 2, 20000, 16590, '2022-05-01', '2022-08-31'),
(6, 2, 20000, 17590, '2022-09-01', '2022-12-31'),
(7, 3, 25000, 22500, '2022-01-01', '2022-04-30'),
(8, 3, 25000, 21790, '2022-05-01', '2022-08-31'),
(9, 3, 25000, 22250, '2022-09-01', '2022-12-31'),
(10, 4, 2000, 1500, '2022-01-01', '2022-04-30'),
(11, 4, 2000, 1290, '2022-05-01', '2022-08-31'),
(12, 4, 2000, 1850, '2022-09-01', '2022-12-31'),
(13, 5, 3000, 2750, '2022-01-01', '2022-04-30'),
(14, 5, 3000, 2500, '2022-05-01', '2022-08-31'),
(15, 5, 3000, 2490, '2022-09-01', '2022-12-31'),
(16, 6, 2500, 2250, '2022-01-01', '2022-04-30'),
(17, 6, 2500, 2500, '2022-05-01', '2022-08-31'),
(18, 6, 2500, 2290, '2022-09-01', '2022-12-31'),
(19, 7, 1500, 1250, '2022-01-01', '2022-04-30'),
(20, 7, 1500, 1500, '2022-05-01', '2022-08-31'),
(21, 7, 1500, 1390, '2022-09-01', '2022-12-31'),
(22, 8, 5000, 4950, '2022-01-01', '2022-04-30'),
(23, 8, 5000, 4350, '2022-05-01', '2022-08-31'),
(24, 8, 5000, 4770, '2022-09-01', '2022-12-31'),
(25, 9, 1000, 900, '2022-01-01', '2022-04-30'),
(26, 9, 1000, 890, '2022-05-01', '2022-08-31'),
(27, 9, 1000, 759, '2022-09-01', '2022-12-31'),
(28, 10, 12000, 11590, '2022-01-01', '2022-04-30'),
(29, 10, 12000, 11000, '2022-05-01', '2022-08-31'),
(30, 10, 12000, 9750, '2022-09-01', '2022-12-31'),
(31, 11, 3000, 2750, '2022-01-01', '2022-04-30'),
(32, 11, 3000, 2500, '2022-05-01', '2022-08-31'),
(33, 11, 3000, 2490, '2022-09-01', '2022-12-31'),
(34, 12, 8000, 7950, '2022-01-01', '2022-04-30'),
(35, 12, 8000, 6990, '2022-05-01', '2022-08-31'),
(36, 12, 8000, 7340, '2022-09-01', '2022-12-31'),
(37, 13, 5000, 4950, '2022-01-01', '2022-04-30'),
(38, 13, 5000, 4350, '2022-05-01', '2022-08-31'),
(39, 13, 5000, 4770, '2022-09-01', '2022-12-31'),
(40, 14, 1700, 1590, '2022-01-01', '2022-04-30'),
(41, 14, 1700, 1300, '2022-05-01', '2022-08-31'),
(42, 14, 1700, 1690, '2022-09-01', '2022-12-31'),
(43, 15, 1000, 900, '2022-01-01', '2022-04-30'),
(44, 15, 1000, 890, '2022-05-01', '2022-08-31'),
(45, 15, 1000, 759, '2022-09-01', '2022-12-31'),
(46, 16, 1800, 1150, '2022-01-01', '2022-04-30'),
(47, 16, 1800, 1100, '2022-05-01', '2022-08-31'),
(48, 16, 1800, 990, '2022-09-01', '2022-12-31'),
(49, 17, 1300, 1290, '2022-01-01', '2022-04-30'),
(50, 17, 1300, 1160, '2022-05-01', '2022-08-31'),
(51, 17, 1300, 1250, '2022-09-01', '2022-12-31'),
(52, 18, 1200, 1150, '2022-01-01', '2022-04-30'),
(53, 18, 1200, 1100, '2022-05-01', '2022-08-31'),
(54, 18, 1200, 990, '2022-09-01', '2022-12-31'),
(55, 19, 1200, 1150, '2022-01-01', '2022-04-30'),
(56, 19, 1200, 1100, '2022-05-01', '2022-08-31'),
(57, 19, 1200, 990, '2022-09-01', '2022-12-31'),
(58, 20, 1200, 1150, '2022-01-01', '2022-04-30'),
(59, 20, 1200, 1100, '2022-05-01', '2022-08-31'),
(60, 20, 1200, 990, '2022-09-01', '2022-12-31'),
(61, 21, 2200, 2150, '2022-01-01', '2022-04-30'),
(62, 21, 2200, 2100, '2022-05-01', '2022-08-31'),
(63, 21, 2200, 1990, '2022-09-01', '2022-12-31'),
(64, 22, 1300, 1290, '2022-01-01', '2022-04-30'),
(65, 22, 1300, 1160, '2022-05-01', '2022-08-31'),
(66, 22, 1300, 1160, '2022-09-01', '2022-12-31'),
(67, 23, 850, 800, '2022-01-01', '2022-04-30'),
(68, 23, 850, 800, '2022-05-01', '2022-08-31'),
(69, 23, 850, 790, '2022-09-01', '2022-12-31'),
(70, 24, 450, 429, '2022-01-01', '2022-04-30'),
(71, 24, 450, 429, '2022-05-01', '2022-08-31'),
(72, 24, 450, 429, '2022-09-01', '2022-12-31'),
(73, 25, 2500, 2250, '2022-01-01', '2022-04-30'),
(74, 25, 2500, 2250, '2022-05-01', '2022-08-31'),
(75, 25, 2500, 2250, '2022-09-01', '2022-12-31'),
(76, 26, 2500, 2290, '2022-01-01', '2022-04-30'),
(77, 26, 2500, 2290, '2022-05-01', '2022-08-31'),
(78, 26, 2500, 2290, '2022-09-01', '2022-12-31'),
(79, 27, 700, 650, '2022-01-01', '2022-04-30'),
(80, 27, 700, 629, '2022-05-01', '2022-08-31'),
(81, 27, 700, 590, '2022-09-01', '2022-12-31'),
(82, 28, 700, 650, '2022-01-01', '2022-04-30'),
(83, 28, 700, 629, '2022-05-01', '2022-08-31'),
(84, 28, 700, 590, '2022-09-01', '2022-12-31'),
(85, 29, 3600, 3550, '2022-01-01', '2022-04-30'),
(86, 29, 3600, 3470, '2022-05-01', '2022-08-31'),
(87, 29, 3600, 3590, '2022-09-01', '2022-12-31'),
(88, 30, 3600, 3550, '2022-01-01', '2022-04-30'),
(89, 30, 3600, 3470, '2022-05-01', '2022-08-31'),
(90, 30, 3600, 3590, '2022-09-01', '2022-12-31'),
(91, 31, 1200, 1150, '2022-01-01', '2022-04-30'),
(92, 31, 1200, 1100, '2022-05-01', '2022-08-31'),
(93, 31, 1200, 990, '2022-09-01', '2022-12-31'),
(94, 32, 1200, 1150, '2022-01-01', '2022-04-30'),
(95, 32, 1200, 1100, '2022-05-01', '2022-08-31'),
(96, 32, 1200, 990, '2022-09-01', '2022-12-31'),
(97, 33, 2200, 2150, '2022-01-01', '2022-04-30'),
(98, 33, 2200, 2090, '2022-05-01', '2022-08-31'),
(99, 33, 2200, 1990, '2022-09-01', '2022-12-31'),
(100, 34, 2200, 2150, '2022-01-01', '2022-04-30'),
(101, 34, 2200, 2090, '2022-05-01', '2022-08-31'),
(102, 34, 2200, 1990, '2022-09-01', '2022-12-31'),
(103, 35, 4600, 4529, '2022-01-01', '2022-04-30'),
(104, 35, 4600, 4390, '2022-05-01', '2022-08-31'),
(105, 35, 4600, 4500, '2022-09-01', '2022-12-31'),
(106, 36, 4600, 4529, '2022-01-01', '2022-04-30'),
(107, 36, 4600, 4390, '2022-05-01', '2022-08-31'),
(108, 36, 4600, 4500, '2022-09-01', '2022-12-31'),
(109, 37, 1500, 1250, '2022-01-01', '2022-04-30'),
(110, 37, 1500, 1500, '2022-05-01', '2022-08-31'),
(111, 37, 1500, 1390, '2022-09-01', '2022-12-31'),
(112, 38, 1500, 1250, '2022-01-01', '2022-04-30'),
(113, 38, 1500, 1500, '2022-05-01', '2022-08-31'),
(114, 38, 1500, 1390, '2022-09-01', '2022-12-31'),
(115, 39, 1500, 1250, '2022-01-01', '2022-04-30'),
(116, 39, 1500, 1500, '2022-05-01', '2022-08-31'),
(117, 39, 1500, 1390, '2022-09-01', '2022-12-31'),
(118, 40, 1500, 1250, '2022-01-01', '2022-04-30'),
(119, 40, 1500, 1500, '2022-05-01', '2022-08-31'),
(120, 40, 1500, 1390, '2022-09-01', '2022-12-31'),
(121, 41, 2300, 2290, '2022-01-01', '2022-04-30'),
(122, 41, 2300, 2179, '2022-05-01', '2022-08-31'),
(123, 41, 2300, 1999, '2022-09-01', '2022-12-31'),
(124, 42, 2300, 2290, '2022-01-01', '2022-04-30'),
(125, 42, 2300, 2179, '2022-05-01', '2022-08-31'),
(126, 42, 2300, 1999, '2022-09-01', '2022-12-31'),
(127, 43, 1200, 1150, '2022-01-01', '2022-04-30'),
(128, 43, 1200, 1100, '2022-05-01', '2022-08-31'),
(129, 43, 1200, 990, '2022-09-01', '2022-12-31'),
(130, 44, 1200, 1150, '2022-01-01', '2022-04-30'),
(131, 44, 1200, 1100, '2022-05-01', '2022-08-31'),
(132, 44, 1200, 990, '2022-09-01', '2022-12-31'),
(133, 45, 1200, 1150, '2022-01-01', '2022-04-30'),
(134, 45, 1200, 1100, '2022-05-01', '2022-08-31'),
(135, 45, 1200, 990, '2022-09-01', '2022-12-31'),
(136, 46, 1200, 1150, '2022-01-01', '2022-04-30'),
(137, 46, 1200, 1100, '2022-05-01', '2022-08-31'),
(138, 46, 1200, 990, '2022-09-01', '2022-12-31'),
(139, 47, 2200, 2150, '2022-01-01', '2022-04-30'),
(140, 47, 2200, 2090, '2022-05-01', '2022-08-31'),
(141, 47, 2200, 1990, '2022-09-01', '2022-12-31'),
(142, 48, 3500, 3200, '2022-01-01', '2022-04-30'),
(143, 48, 3500, 3250, '2022-05-01', '2022-08-31'),
(144, 48, 3500, 3190, '2022-09-01', '2022-12-31'),
(145, 49, 3500, 2990, '2022-01-01', '2022-04-30'),
(146, 49, 3500, 3350, '2022-05-01', '2022-08-31'),
(147, 49, 3500, 3159, '2022-09-01', '2022-12-31'),
(148, 50, 4500, 4390, '2022-01-01', '2022-04-30'),
(149, 50, 4500, 4190, '2022-05-01', '2022-08-31'),
(150, 50, 4500, 3950, '2022-09-01', '2022-12-31'),
(151, 51, 4500, 4500, '2022-01-01', '2022-04-30'),
(152, 51, 4500, 4239, '2022-05-01', '2022-08-31'),
(153, 51, 4500, 4450, '2022-09-01', '2022-12-31'),
(154, 52, 5000, 4980, '2022-01-01', '2022-04-30'),
(155, 52, 5000, 4586, '2022-05-01', '2022-08-31'),
(156, 52, 5000, 4750, '2022-09-01', '2022-12-31'),
(157, 53, 5000, 4750, '2022-01-01', '2022-04-30'),
(158, 53, 5000, 4800, '2022-05-01', '2022-08-31'),
(159, 53, 5000, 4790, '2022-09-01', '2022-12-31'),
(160, 54, 8000, 7500, '2022-01-01', '2022-04-30'),
(161, 54, 8000, 7350, '2022-05-01', '2022-08-31'),
(162, 54, 8000, 7890, '2022-09-01', '2022-12-31'),
(163, 55, 8000, 7290, '2022-01-01', '2022-04-30'),
(164, 55, 8000, 7500, '2022-05-01', '2022-08-31'),
(165, 55, 8000, 7490, '2022-09-01', '2022-12-31');

-- --------------------------------------------------------

--
-- Table structure for table `main_reference_number`
--

CREATE TABLE `main_reference_number` (
  `ReferenceNumber` int(12) NOT NULL,
  `UserID` int(11) NOT NULL,
  `BookingDateTime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `PriceTotalPayment` double NOT NULL,
  `PaymentMethod_ID` int(5) NOT NULL,
  `CardNumber` varchar(16) DEFAULT NULL,
  `DateTimePayment` datetime NOT NULL DEFAULT current_timestamp(),
  `TaxandFee` double NOT NULL,
  `GuestName` varchar(30) DEFAULT NULL,
  `Phone_Guest` varchar(15) DEFAULT NULL,
  `Message` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `main_reference_number`
--

INSERT INTO `main_reference_number` (`ReferenceNumber`, `UserID`, `BookingDateTime`, `PriceTotalPayment`, `PaymentMethod_ID`, `CardNumber`, `DateTimePayment`, `TaxandFee`, `GuestName`, `Phone_Guest`, `Message`) VALUES
(1, 2, '2022-01-12 08:15:00', 34750, 1, '4322345431236540', '2022-01-12 15:15:00', 2432.5, 'Nirosesofia', '(480) 555-0112', NULL),
(2, 2, '2022-01-14 18:15:00', 3940, 1, '', '2022-01-15 01:15:00', 275.8, 'Arlene', '(480) 555-0113', 'Great Service!!'),
(3, 2, '2022-01-16 09:25:00', 19140, 1, '', '2022-01-16 16:25:00', 1339.8, 'Wade', '(480) 555-0114', NULL),
(4, 2, '2022-01-20 11:05:00', 24180, 1, '4322345431236540', '2022-01-20 18:05:00', 1692.6, 'Darrell', '(480) 555-0115', 'No smoking'),
(5, 2, '2022-01-21 08:17:00', 33900, 1, '', '2022-01-21 15:17:00', 2373, 'Hony', '(480) 555-0116', NULL),
(6, 2, '2022-01-23 08:15:00', 3200, 1, '4322345431236540', '2022-01-23 15:15:00', 224, 'Kirigaya', '012-345-6789', NULL),
(7, 2, '2022-01-28 08:15:00', 44980, 1, '', '2022-01-28 15:15:00', 3148.6, 'Yuuki', '055-155-5511', NULL),
(8, 2, '2022-02-07 08:15:00', 12780, 1, '', '2022-02-07 15:15:00', 894.6, 'Nobi', '033-444-5566', NULL),
(9, 2, '2022-02-12 08:15:00', 3500, 1, '', '2022-02-12 15:15:00', 245, 'Gouda', '099-987-6543', NULL),
(10, 2, '2022-02-16 08:15:00', 27500, 1, '', '2022-02-16 15:15:00', 1925, 'Midoriya', '044-6342-5876', NULL),
(11, 2, '2022-02-20 08:15:00', 9960, 1, '4322345431236550', '2022-02-20 15:15:00', 697.2, 'Uraraka', '023-423-3111', NULL),
(12, 2, '2022-02-22 08:15:00', 14580, 1, '4322345431236550', '2022-02-22 15:15:00', 1020.6, 'Mike', '018-246-3579', NULL),
(13, 2, '2022-02-24 08:15:00', 8500, 1, '', '2022-02-24 15:15:00', 595, 'Kamado', '044-674-9753', NULL),
(14, 2, '2022-03-04 08:15:00', 15000, 1, '4322345431236550', '2022-03-04 15:15:00', 1050, 'Zenitsu', '039-485-6758', NULL),
(15, 2, '2022-03-05 08:15:00', 41470, 1, '', '2022-03-05 15:15:00', 2902.9, 'John', '044-555-5555', NULL),
(16, 2, '2022-03-07 08:15:00', 8250, 1, '4322345431236550', '2022-03-07 15:15:00', 577.5, 'Cody', '012-345-6715', NULL),
(17, 2, '2022-03-12 08:15:00', 1250, 1, '', '2022-03-12 15:15:00', 87.5, 'Devon', '012-345-6716', NULL),
(18, 2, '2022-03-20 08:15:00', 25417, 1, '4322345431236560', '2022-03-20 15:15:00', 1779.19, 'Esther', '043-6342-5876', NULL),
(19, 2, '2022-03-21 08:15:00', 17270, 1, '', '2022-03-21 15:15:00', 1208.9, 'Kathryn', '043-6342-5877', NULL),
(20, 2, '2022-03-21 02:31:00', 9000, 1, '4322345431236560', '2022-03-21 09:31:00', 630, 'Wade', '043-6342-5878', NULL),
(21, 2, '2022-03-24 08:15:00', 1290, 1, '4322345431236560', '2022-03-24 15:15:00', 90.3, 'Savannah', '043-6342-5879', NULL),
(22, 2, '2022-03-25 08:15:00', 2300, 1, '', '2022-03-25 15:15:00', 161, 'Saburo', '043-6342-5880', NULL),
(23, 2, '2022-03-26 08:15:00', 15290, 1, '', '2022-03-26 15:15:00', 1070.3, 'Masato', '012-345-6722', NULL),
(24, 2, '2022-03-30 08:15:00', 6318, 1, '', '2022-03-30 15:15:00', 442.26, 'Otake', '012-345-6723', NULL),
(25, 2, '2022-04-01 08:15:00', 14580, 1, '', '2022-04-01 15:15:00', 1020.6, 'Prayuay', '012-345-6724', NULL),
(26, 2, '2022-04-05 08:15:00', 3060, 1, '4322345431236560', '2022-04-05 15:15:00', 214.2, 'Chowkuay', '012-345-6725', NULL),
(27, 2, '2022-04-06 08:15:00', 2200, 1, '4322345431236560', '2022-04-06 15:15:00', 154, 'Lodchong', '012-345-6726', NULL),
(28, 2, '2022-04-11 08:15:00', 12375, 1, '', '2022-04-11 15:15:00', 866.25, 'North', '012-345-6727', NULL),
(29, 2, '2022-04-17 11:21:00', 4680, 1, '4322345431236570', '2022-04-17 18:21:00', 327.6, 'Kibzy', '012-345-6728', NULL),
(30, 2, '2022-04-18 08:15:00', 30800, 1, '', '2022-04-18 15:15:00', 2156, 'New', '012-345-6729', NULL),
(34, 7, '2022-05-15 12:43:55', 27498, 1, '12345678910', '2022-05-15 19:43:55', 1798, 'Nirosesofia Phamonpol', '0658428852', 'Please nice welcome'),
(35, 7, '2022-05-15 12:47:00', 30120, 1, '12345678910', '2022-05-15 19:47:00', 1970, 'Nirosesofia Phamonpol', '0658428852', 'Please nice welcome'),
(36, 7, '2022-05-15 13:00:37', 6398, 1, '12345678910', '2022-05-15 20:00:37', 418, 'Nirosesofia Phamonpol', '0658428852', 'clean room'),
(37, 7, '2022-05-15 13:02:55', 17590, 1, '12345678910', '2022-05-15 20:02:55', 1150, 'Nirosesofia Phamonpol', '0658428852', 'Please nice welcome'),
(38, 7, '2022-05-15 13:40:20', 6848, 1, '12345678910', '2022-05-15 20:40:20', 448, 'Nirosesofia Phamonpol', '0658428852', 'clean room'),
(39, 7, '2022-05-15 13:41:40', 695, 2, '', '2022-05-15 20:41:40', 45, 'Nirosesofia Phamonpol', '0658428852', ''),
(40, 7, '2022-05-15 13:42:40', 19260, 3, '', '2022-05-15 20:42:40', 1260, 'Sarunwarin', '0871112234', 'want driver'),
(41, 7, '2022-05-15 13:43:26', 24802, 4, '', '2022-05-15 20:43:26', 1622, 'Sarunwarin', '0871112234', 'want driver'),
(42, 7, '2022-05-15 13:44:24', 1230, 1, '12345678910', '2022-05-15 20:44:24', 80, 'Nirosesofia Phamonpol', '0658428852', ''),
(43, 7, '2022-05-15 13:48:21', 28868, 1, '12345678910', '2022-05-15 20:48:21', 1888, 'Sarunwarin', '0871112234', 'Please nice welcome'),
(44, 7, '2022-05-15 17:28:42', 16050, 1, '12345678910', '2022-05-16 00:28:42', 1050, 'Nirosesofia Phamonpol', '0658428852', 'clean room'),
(45, 7, '2022-05-15 17:29:34', 1230, 1, '12345678910', '2022-05-16 00:29:34', 80, 'Sarunwarin', '0658428852', ''),
(46, 7, '2022-05-15 17:33:23', 4761, 1, '12345678910', '2022-05-16 00:33:23', 311, 'Sarunwarin', '0658428852', 'Please nice welcome'),
(47, 7, '2022-05-16 03:21:09', 6848, 1, '12345678910', '2022-05-16 10:21:09', 448, 'Nirosesofia Phamonpol', '0658428852', 'clean room'),
(48, 7, '2022-05-16 03:21:58', 1230, 3, '', '2022-05-16 10:21:58', 80, 'Sarunwarin', '0871112234', ''),
(49, 7, '2022-05-16 03:24:48', 21292, 1, '12345678910', '2022-05-16 10:24:48', 1392, 'Nirosesofia Phamonpol', '0658428852', 'Please nice welcome'),
(50, 7, '2022-05-16 04:21:59', 15600, 1, '12345678910', '2022-05-16 11:21:59', 1020, 'Nirosesofia Phamonpol', '0658428852', 'clean room'),
(51, 7, '2022-05-16 04:22:36', 1230, 2, '', '2022-05-16 11:22:36', 80, 'Sarunwarin', '0871112234', ''),
(52, 7, '2022-05-16 04:25:16', 23004, 1, '12345678910', '2022-05-16 11:25:16', 1504, 'Nirosesofia Phamonpol', '0871112234', 'Please nice welcome'),
(53, 7, '2022-05-16 06:22:16', 16050, 1, '12345678910', '2022-05-16 13:22:16', 1050, 'Nirosesofia Phamonpol', '0658428852', 'clean room'),
(54, 7, '2022-05-16 06:22:54', 963, 2, '', '2022-05-16 13:22:54', 63, 'Sarunwarin', '0871112234', 'none'),
(55, 7, '2022-05-16 06:25:18', 24663, 1, '12345678910', '2022-05-16 13:25:18', 1613, 'Nirosesofia Phamonpol', '0658428852', 'none');

-- --------------------------------------------------------

--
-- Table structure for table `partial_reference_number`
--

CREATE TABLE `partial_reference_number` (
  `Reference_PartialNumber` int(12) NOT NULL,
  `ReferenceNumber` int(12) NOT NULL,
  `Booking_ID` int(6) NOT NULL,
  `MemberGuest` int(11) NOT NULL,
  `CheckInDateTime` datetime NOT NULL,
  `CheckOutDateTime` datetime NOT NULL,
  `Staff_ID` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `partial_reference_number`
--

INSERT INTO `partial_reference_number` (`Reference_PartialNumber`, `ReferenceNumber`, `Booking_ID`, `MemberGuest`, `CheckInDateTime`, `CheckOutDateTime`, `Staff_ID`) VALUES
(1, 1, 53, 7, '2022-01-20 14:00:00', '2022-01-22 12:00:00', 100003),
(2, 1, 3, 3, '2022-01-21 15:00:00', '2022-01-22 21:00:00', 100003),
(3, 1, 10, 2, '2022-01-21 12:00:00', '2022-01-22 18:00:00', 100003),
(4, 2, 49, 5, '2022-02-02 14:00:00', '2022-02-03 12:00:00', 100003),
(5, 2, 33, 1, '2022-02-03 13:00:00', '2022-02-03 14:30:00', 100003),
(6, 3, 51, 6, '2022-03-20 14:00:00', '2022-03-22 12:00:00', 100003),
(7, 3, 48, 5, '2022-03-20 14:00:00', '2022-03-22 12:00:00', 100003),
(8, 3, 19, 4, '2022-03-20 18:00:00', '2022-03-22 23:00:00', 100003),
(9, 3, 16, 4, '2022-03-20 18:00:00', '2022-03-22 23:30:00', 100003),
(10, 4, 55, 8, '2022-04-02 14:00:00', '2022-04-04 12:00:00', 100003),
(11, 4, 20, 4, '2022-04-03 18:00:00', '2022-04-03 23:30:00', 100003),
(12, 5, 53, 7, '2022-02-21 14:00:00', '2022-02-25 12:00:00', 100003),
(13, 5, 13, 2, '2022-02-23 09:00:00', '2022-02-24 09:00:00', 100003),
(14, 5, 32, 1, '2022-02-25 13:00:00', '2022-02-25 14:30:00', 100003),
(15, 6, 48, 5, '2022-05-17 14:00:00', '2022-05-18 12:00:00', 100003),
(16, 7, 49, 5, '2022-03-28 14:30:00', '2022-03-30 12:00:00', 100003),
(17, 7, 2, 3, '2022-03-28 15:00:00', '2022-03-28 21:00:00', 100003),
(18, 7, 37, 1, '2022-03-29 13:00:00', '2022-03-29 14:30:00', 100003),
(19, 7, 38, 1, '2022-03-30 09:00:00', '2022-03-30 10:30:00', 100003),
(20, 7, 29, 4, '2022-03-29 18:00:00', '2022-03-29 23:30:00', 100003),
(21, 8, 49, 5, '2022-03-27 14:30:00', '2022-03-30 11:30:00', 100003),
(22, 8, 16, 4, '2022-03-29 18:00:00', '2022-03-29 23:30:00', 100003),
(23, 9, 49, 5, '2022-03-31 14:30:00', '2022-04-01 10:30:00', 100003),
(24, 10, 50, 6, '2022-04-01 14:30:00', '2022-04-02 11:00:00', 100003),
(25, 10, 1, 3, '2022-04-01 15:00:00', '2022-04-01 21:00:00', 100003),
(26, 10, 9, 2, '2022-04-01 14:30:00', '2022-04-02 15:00:00', 100003),
(27, 11, 52, 7, '2022-03-31 14:30:00', '2022-04-02 11:00:00', 100003),
(28, 12, 55, 8, '2022-03-30 14:30:00', '2022-04-01 09:30:00', 100003),
(29, 13, 49, 5, '2022-03-31 14:00:00', '2022-04-01 12:00:00', 100003),
(30, 14, 16, 4, '2022-03-31 18:00:00', '2022-03-31 23:30:00', 100003),
(31, 14, 54, 8, '2022-03-06 14:00:00', '2022-03-08 12:00:00', 100003),
(32, 15, 55, 8, '2022-03-12 14:00:00', '2022-03-14 12:00:00', 100003),
(33, 15, 21, 4, '2022-03-13 18:00:00', '2022-03-13 23:30:00', 100003),
(34, 15, 37, 1, '2022-03-13 13:00:00', '2022-03-13 14:30:00', 100003),
(35, 15, 1, 3, '2022-03-12 15:00:00', '2022-03-12 21:00:00', 100003),
(36, 15, 29, 1, '2022-03-13 13:30:00', '2022-03-13 14:30:00', 100003),
(37, 16, 50, 2, '2022-03-14 14:00:00', '2022-03-16 12:00:00', 100003),
(38, 17, 16, 4, '2022-03-12 13:30:00', '2022-03-12 15:00:00', 100003),
(39, 18, 49, 5, '2022-03-25 14:00:00', '2022-03-28 12:00:00', 100003),
(40, 18, 32, 1, '2022-03-26 10:30:00', '2022-03-26 12:00:00', 100003),
(41, 18, 3, 3, '2022-03-27 12:30:00', '2022-03-27 14:00:00', 100003),
(42, 18, 2, 3, '2022-03-27 15:00:00', '2022-03-27 21:00:00', 100003),
(43, 19, 2, 3, '2022-03-15 15:00:00', '2022-03-15 21:00:00', 100003),
(44, 19, 18, 3, '2022-04-03 18:00:00', '2022-04-03 23:30:00', 100003),
(45, 20, 51, 6, '2022-04-09 14:00:00', '2022-04-11 12:00:00', 100003),
(46, 21, 27, 1, '2022-04-25 10:30:00', '2022-04-25 12:00:00', 100003),
(47, 22, 19, 4, '2022-04-02 18:00:00', '2022-04-02 23:30:00', 100003),
(48, 23, 49, 5, '2022-04-08 14:00:00', '2022-04-10 12:00:00', 100003),
(49, 23, 5, 2, '2022-04-01 14:30:00', '2022-04-02 14:30:00', 100003),
(50, 23, 55, 8, '2022-04-09 14:00:00', '2022-04-12 12:00:00', 100003),
(51, 24, 49, 5, '2022-04-09 14:00:00', '2022-04-12 12:00:00', 100003),
(53, 26, 49, 5, '2022-01-01 14:00:00', '2022-04-30 12:00:00', 100003),
(54, 27, 42, 1, '2022-02-04 15:00:00', '2022-02-05 16:30:00', 100003),
(55, 28, 50, 6, '2022-01-01 14:00:00', '2022-04-30 12:00:00', 100003),
(56, 29, 52, 7, '2022-05-01 14:00:00', '2022-08-31 12:00:00', 100003),
(57, 30, 55, 8, '2022-09-01 14:00:00', '2022-12-31 12:00:00', 100003),
(73, 34, 51, 2, '2022-05-17 12:00:00', '2022-05-19 12:00:00', 100001),
(74, 34, 27, 1, '2022-05-20 19:30:00', '2022-05-20 21:30:00', 100001),
(75, 34, 1, 17, '2022-05-22 12:00:00', '2022-05-22 12:00:00', 100001),
(76, 34, 6, 2, '2022-05-21 12:00:00', '2022-05-22 12:00:00', 100001),
(77, 34, 15, 1, '2022-05-19 20:30:00', '2022-05-19 22:30:00', 100001),
(78, 35, 51, 2, '2022-05-20 12:00:00', '2022-05-22 12:00:00', 100001),
(79, 35, 2, 17, '2022-05-21 12:00:00', '2022-05-21 12:00:00', 100001),
(80, 35, 18, 1, '2022-05-18 20:46:00', '2022-05-18 22:46:00', 100001),
(81, 36, 49, 2, '2022-05-20 12:00:00', '2022-05-22 12:00:00', 100001),
(82, 37, 1, 17, '2022-05-20 12:00:00', '2022-05-20 12:00:00', 100001),
(83, 37, 6, 2, '2022-05-23 12:00:00', '2022-05-24 12:00:00', 100001),
(84, 37, 17, 1, '2022-05-17 20:30:00', '2022-05-17 22:30:00', 100001),
(85, 38, 48, 2, '2022-05-20 12:00:00', '2022-05-22 12:00:00', 100001),
(86, 39, 27, 1, '2022-05-16 14:30:00', '2022-05-16 16:30:00', 100001),
(87, 40, 2, 17, '2022-05-16 12:00:00', '2022-05-16 23:00:00', 100001),
(88, 41, 10, 2, '2022-05-20 10:00:00', '2022-05-22 12:00:00', 100001),
(89, 42, 18, 1, '2022-05-20 22:30:00', '2022-05-21 00:30:00', 100001),
(90, 43, 26, 1, '2022-05-20 08:57:00', '2022-05-20 10:57:00', 100001),
(91, 43, 3, 18, '2022-05-20 12:00:00', '2022-05-20 12:00:00', 100001),
(92, 43, 9, 2, '2022-05-22 12:00:00', '2022-05-23 12:00:00', 100001),
(93, 43, 17, 1, '2022-05-20 20:46:00', '2022-05-20 22:46:00', 100001),
(94, 44, 54, 2, '2022-05-20 12:00:00', '2022-05-22 12:00:00', 100001),
(95, 45, 18, 1, '2022-05-20 10:30:00', '2022-05-20 12:30:00', 100001),
(96, 46, 9, 2, '2022-05-20 12:00:00', '2022-05-21 12:00:00', 100001),
(97, 46, 29, 1, '2022-05-20 12:32:00', '2022-05-20 14:32:00', 100001),
(98, 47, 48, 2, '2022-05-20 12:00:00', '2022-05-22 12:00:00', 100001),
(99, 48, 16, 1, '2022-05-19 13:21:00', '2022-05-19 15:21:00', 100001),
(100, 49, 27, 1, '2022-05-20 13:22:00', '2022-05-20 15:22:00', 100001),
(101, 49, 2, 17, '2022-05-20 12:00:00', '2022-05-20 12:00:00', 100001),
(102, 49, 7, 2, '2022-05-20 12:00:00', '2022-05-21 12:00:00', 100001),
(103, 50, 55, 2, '2022-05-20 12:00:00', '2022-05-22 12:00:00', 100001),
(104, 51, 16, 1, '2022-05-20 13:22:00', '2022-05-20 15:22:00', 100001),
(105, 52, 27, 1, '2022-05-20 13:25:00', '2022-05-20 15:25:00', 100001),
(106, 52, 1, 17, '2022-05-22 12:00:00', '2022-05-22 12:00:00', 100001),
(107, 52, 12, 2, '2022-05-19 12:00:00', '2022-05-20 12:00:00', 100001),
(108, 53, 54, 2, '2022-05-20 12:00:00', '2022-05-22 12:00:00', 100001),
(109, 54, 15, 1, '2022-05-20 16:22:00', '2022-05-20 18:22:00', 100001),
(110, 55, 28, 1, '2022-05-20 13:23:00', '2022-05-20 15:23:00', 100001),
(111, 55, 1, 17, '2022-05-20 12:00:00', '2022-05-20 12:00:00', 100001),
(112, 55, 8, 2, '2022-05-20 12:00:00', '2022-05-22 12:00:00', 100001);

-- --------------------------------------------------------

--
-- Table structure for table `payment_method`
--

CREATE TABLE `payment_method` (
  `PaymentMethod_ID` varchar(5) NOT NULL,
  `PaymentMethod_Name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `payment_method`
--

INSERT INTO `payment_method` (`PaymentMethod_ID`, `PaymentMethod_Name`) VALUES
('1', 'Credit card'),
('2', 'Money'),
('3', 'Paypal'),
('4', 'PromptPay');

-- --------------------------------------------------------

--
-- Table structure for table `position`
--

CREATE TABLE `position` (
  `PositionID` varchar(4) NOT NULL,
  `PositionName` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `position`
--

INSERT INTO `position` (`PositionID`, `PositionName`) VALUES
('P001', 'Manager'),
('P002', 'Admin'),
('P003', 'Cleaning'),
('P004', 'Service');

-- --------------------------------------------------------

--
-- Table structure for table `staff_information`
--

CREATE TABLE `staff_information` (
  `Staff_ID` int(6) NOT NULL,
  `BranchHotel_ID` varchar(4) NOT NULL,
  `Firstname` varchar(20) NOT NULL,
  `Lastname` varchar(20) NOT NULL,
  `Staff_Phone` varchar(15) NOT NULL,
  `Address_staff` text NOT NULL,
  `DOB` date NOT NULL,
  `Gender` enum('M','F') NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password_staff` varchar(225) NOT NULL,
  `Nationality` text NOT NULL,
  `Religion` text DEFAULT NULL,
  `MaritalStatus` text DEFAULT NULL,
  `PositionID` varchar(4) NOT NULL,
  `WorkStationID` varchar(5) NOT NULL,
  `Salary` double NOT NULL,
  `StartWorkDate` date NOT NULL,
  `Endworkdate` date DEFAULT NULL,
  `Status_Staff_ID` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `staff_information`
--

INSERT INTO `staff_information` (`Staff_ID`, `BranchHotel_ID`, `Firstname`, `Lastname`, `Staff_Phone`, `Address_staff`, `DOB`, `Gender`, `Email`, `Password_staff`, `Nationality`, `Religion`, `MaritalStatus`, `PositionID`, `WorkStationID`, `Salary`, `StartWorkDate`, `Endworkdate`, `Status_Staff_ID`) VALUES
(100001, 'BR03', 'Leslie', 'Alexanderder', '(209) 555-0104', '8502 Preston Rd. Inglewood, Maine 98380', '1992-04-04', 'F', 'Alexander@gmail.com', '', 'Australian', 'Christianity', 'Married', 'P004', 'FL999', 45000, '2017-06-08', NULL, '100'),
(100002, 'BR02', 'Darrell', 'Steward', '(480) 555-0103', '1901 Thornridge Cir. Shiloh, Hawaii 81063', '2000-12-10', 'M', 'Steward@gmail.com', 'Steward123', 'French', 'Christianity', 'married', 'P001', 'FL999', 35000, '2017-06-08', NULL, '101'),
(100003, 'BR03', 'Albert', 'Flores', '(208) 555-0112', '4517 Washington Ave. Manchester, Kentucky 39495', '1998-05-07', 'M', 'Flores@gmail.com', '', 'Chinese', 'Buddhism', 'Married', 'P004', 'FL999', 30000, '2017-06-08', NULL, '100'),
(100004, 'BR02', 'Cameron', 'Williamson', '(480) 555-0103', '4140 Parker Rd. Allentown, New Mexico 31134', '1995-09-23', 'M', 'Williamson@gmail.com', 'Williamson123', 'Australian', 'Christianity', 'married', 'P002', 'FL555', 32000, '2017-06-08', NULL, '101'),
(100005, 'BR01', 'Courtney', 'Henry', '(229) 555-0109', '3891 Ranchview Dr. Richardson, California 62639', '1995-01-08', 'M', 'Henry@gmail.com', 'Henry123', 'Chinese', 'Buddhism', 'married', 'P002', 'Fl555', 31000, '2017-07-04', NULL, '101'),
(100006, 'BR03', 'Arlene', 'McCoy', '(702) 555-0122', '2118 Thornridge Cir. Syracuse, Connecticut 35624', '1988-01-31', 'F', 'McCoy@gmail.com', 'McCoy123', 'Thai', 'Christianity', 'Single', 'P001', 'FL999', 40000, '2017-07-07', NULL, '101'),
(100007, 'BR03', 'Cody', 'Fisher', '(405) 555-0128', '2464 Royal Ln. Mesa, New Jersey 45463', '2002-02-11', 'M', 'Fisher@gmail.com', 'Fisher123', 'Australian', 'Islam', 'married', 'P002', 'FL555', 32000, '2017-07-07', NULL, '100'),
(100008, 'BR01', 'Devon', 'Lane', '(219) 555-0114', '6391 Elgin St. Celina, Delaware 10299', '1999-12-04', 'M', 'Lane@gmail.com', 'Lane123', 'Thai', 'Christianity', 'Single', 'P003', 'FL101', 15000, '2017-07-07', NULL, '100'),
(100009, 'BR02', 'Esther', 'Howard', '(603) 555-0123', '2972 Westheimer Rd. Santa Ana, Illinois 85486', '1994-05-12', 'F', 'Howard@gmail.com', 'Howard123', 'Australian', 'Islam', 'Single', 'P002', 'FL555', 32000, '2017-08-23', NULL, '101'),
(100010, 'BR03', 'Kathryn', 'Murphy', '(808) 555-0111', '3517 W. Gray St. Utica, Pennsylvania 57867', '1992-09-18', 'F', 'Murphy@gmail.com', 'Murphy123', 'Thai', 'Christianity', 'married', 'P002', 'FL555', 35000, '2017-08-23', NULL, '100'),
(100011, 'BR01', 'Wade', 'Warren', '(209) 555-0104', '7 Ayres Drive, Cowlersley, HD4 5TX', '2001-05-27', 'F', 'Warren@gmail.com', 'Warren123', 'Thai', 'Buddhism', 'Single', 'P004', 'FL201', 22000, '2017-09-11', NULL, '100'),
(100012, 'BR02', 'Savannah', 'Nguyen', '(225) 555-0118', '12 Peel Walk, Birmingham, B17 8SR', '1990-05-27', 'F', 'Nguyen@gmail.com', 'Nguyen123', 'Thai', 'Buddhism', 'Single', 'P004', 'FL301', 25000, '2017-10-03', NULL, '101'),
(100013, 'BR03', 'Saburo', 'Nakamura', '(81) 555-0120', '410-1109, Nijo Dencho, Nakagyo-ku-shi, Nakagyo-ku Kyoto-shi, Kyoto', '1999-08-23', 'M', 'Nakamura123@gmail.com', 'Nakamura123', 'Japanese', 'Shinto', 'Single', 'P003', 'FL101', 18000, '2017-10-03', NULL, '101'),
(100014, 'BR02', 'Masato', 'Nakazawa', '(81) 555-0125', '376-1209, Takinoshita,Rausu-cho Menashi-gun,Hokkaido', '1980-03-02', 'M', 'Nakazawa32@gmail.com', 'Nakazawa3280', 'Japanese', 'Shinto', 'Single', 'P003', 'FL101', 18000, '2017-10-03', NULL, '101'),
(100015, 'BR03', 'Otake', 'Shiro', '(81) 555-0321', '436-1212, Kita 3-jo, Hamatombetsu-cho Esashi-gun, Hokkaido', '2002-02-22', 'F', 'Shirotake@gmail.com', 'Shirotake123', 'Japanese', 'Shinto', 'married', 'P004', 'FL302', 20000, '2017-12-20', NULL, '100'),
(100016, 'BR01', 'Prayuay', 'Huakud', '(66) 234-5512', '5/5-6 Soi Kingpetch, Petchburi Road, Rajthevee, Rajthevee, Bangkok 10400', '2000-03-13', 'M', 'Huakud@gmail.com', 'Huakud123', 'Thai', 'Buddhism', 'Single', 'P004', 'FL301', 25000, '2017-12-20', NULL, '101'),
(100017, 'BR03', 'Chowkuay', 'Chakanrao', '(66) 268-9617', 'Krabi Road, Mueang Krabi, Krabi 81000', '1996-12-24', 'M', 'Chowkuy@gmail.com', 'Chowkuy123', 'Thai', 'Buddhism', 'Single', 'P004', 'FL301', 25000, '2017-12-20', NULL, '101'),
(100018, 'BR01', 'Lodchong', 'Singapura', '(66) 153-9831', 'Jira Road,Mueang Buriram, Buriram 31000', '1987-07-07', 'F', 'Lodchongaroi@gmail.com', 'Lodchong123', 'Thai', 'Islam', 'married', 'P003', 'FL102', 17000, '2018-01-15', NULL, '101'),
(100019, 'BR03', 'Rath', 'Pikardpairee', '(66) 380-0931', '92 Payalithai Road, Phitsanulok,65000', '2001-07-09', 'M', 'Pikardpairee@gmail.com', 'Ratt12123', 'Thai', 'Christianity', 'married', 'P003', 'FL102', 19000, '2018-01-15', NULL, '100'),
(100020, 'BR02', 'Jisung', 'Yoon', '(82) 555-0111', 'Samseong1-dong, Gangnam-gu, Seoul', '1991-08-03', 'M', 'Jisung_Yoon@gmail.com', 'Loveislettinggooffear', 'South Korea', 'Christianity', 'Single', 'P004', 'FL302', 20000, '2018-01-15', NULL, '101'),
(100021, 'BR02', 'Sungwoon', 'Ha', '(82) 461-9980', 'Jamsilbon-dong, Songpa-gu, Seoul', '1994-03-22', 'M', 'Sungwoon.HaHaHa@gmail.com', 'Chistmasiscomming', 'South Korea', 'Christianity', 'Single', 'P003', 'FL102', 16000, '2018-03-20', NULL, '100'),
(100022, 'BR01', 'Minhyun', 'Hwang', '(82) 684-5135', 'Bongeunsa-ro 67-gil, Gangnam-gu, Seoul, South Korea.', '1995-09-08', 'M', 'Minhyun.hwang@gmail.com', 'happybirthday', 'South Korea', 'Christianity', 'Single', 'P004', 'FL202', 22000, '2018-03-31', NULL, '101'),
(100023, 'BR03', 'Seongwoo', 'Ong', '(82)-555-3506', 'Yeoksam-ro, Gangnam-gu, Seoul, Korea (Yeoksam-dong, fantagio Bldg).', '1995-08-25', 'M', 'Seongwoo_oo@gmail.com', 'Iwillalwaysremember', 'South Korea', 'Christianity', 'Single', 'P004', 'FL201', 22000, '2018-04-01', NULL, '100'),
(100024, 'BR03', 'Jaehwan', 'Kim', '(82) 460-2573', '36-35 Itaewon 1-dong, Yongsan-gu, Seoul, South Korea.', '1996-05-27', 'M', 'Jaehwan@gmail.com', 'SantaClausiscomin\'totown', 'South Korea', 'Christianity', 'Single', 'P003', 'FL103', 16000, '2018-04-20', NULL, '100'),
(100025, 'BR03', 'Daniel', 'Kang', '(82) 343-6117', '7 Eonju-ro 159-gil, Apgujeong-dong, Gangnam-gu, Seoul, South Korea.', '1996-10-12', 'M', 'KangDaniel@gmail.com', 'JingleBells', 'South Korea', 'Christianity', 'Single', 'P003', 'FL104', 17000, '2018-04-20', NULL, '101'),
(100026, 'BR03', 'Jihoon', 'Park', '(82) 326-0594', '2F, 268-16 Nonhyeon-dong, Gangnam-gu, Seoul, South Korea.', '1999-05-29', 'M', 'Park_jihoon@gmail.com', 'Goodness', 'South Korea', 'Christianity', 'Single', 'P004', 'FL202', 22000, '2018-04-20', NULL, '101'),
(100027, 'BR01', 'Woojin', 'Park', '(82) 241-1768', 'Seo ul Teug Byeol Si Seo Cho Gu Bang Bae 1Dong 901-3 Se Myeong Bil Ding 5Cheung, Seoul, South Korea.', '1999-02-11', 'M', 'WoojinPK@gmail.com', 'LastChristmas', 'South Korea', 'Christianity', 'Single', 'P003', 'FL103', 19000, '2018-06-03', NULL, '100'),
(100028, 'BR02', 'Jinyoung', 'Bae', '(82) 406-2984', '41 Dongmak-ro 3-gil, Mapo-gu, Seoul , South Korea', '2000-10-05', 'M', 'JinyoungBae@gmail.com', 'Igaveyoumyheart', 'South Korea', 'Christianity', 'Single', 'P004', 'FL201', 22000, '2018-06-03', NULL, '101'),
(100029, 'BR03', 'Daehwi', 'Lee', '(82) 576-3870', 'Seo ul Teug Byeol Si Seo Cho Gu Bang Bae 1Dong 901-3 Se Myeong Bil Ding 5Cheung, Seoul, South Korea.', '2001-01-29', 'M', 'Daehwilee@gmail.com', 'Nobodyknows', 'South Korea', 'Christianity', 'Single', 'P004', 'FL303', 25000, '2018-06-03', NULL, '100'),
(100030, 'BR02', 'Kuanlin', 'Lai', '(82) 541-6992', 'F2 Building, 83, Achasan-ro, Seongdong-gu, Seoul, South Korea', '2001-09-23', 'M', 'Kuanlin@gmail.com', 'Livefortoday', 'Taiwan', 'Christianity', 'Single', 'P003', 'FL103', 15000, '2018-08-23', NULL, '101'),
(100031, 'BR03', 'Namjoon', 'Kim', '(82) 986-9566', 'Cheonggu Building 3F. 13-20, Dosan-daero 16-gil. Gangnam-gu, Seoul 06040. South Korea.', '1994-12-09', 'M', 'Kim.numjoon@gmail.com', 'Ourstoriesunfold', 'South Korea', 'Christianity', 'Single', 'P003', 'FL105', 15000, '2018-08-25', NULL, '101'),
(100032, 'BR01', 'Seokjin', 'Kim', '(82) 732-8861', 'Cheonggu Building 3F. 13-20, Dosan-daero 16-gil. Gangnam-gu, Seoul 06040. South Korea.', '1992-04-12', 'M', 'Kim.Seokjin@gmail.com', 'Whatatime', 'South Korea', 'Christianity', 'Single', 'P003', 'FL104', 17000, '2018-08-25', NULL, '101'),
(100033, 'BR02', 'Yoongi', 'Min', '(82) 845-2295', 'Cheonggu Building 3F. 13-20, Dosan-daero 16-gil. Gangnam-gu, Seoul 06040. South Korea.', '1993-03-23', 'M', 'Yoongi.M@gmail.com', 'Somebodytoknow', 'South Korea', 'Christianity', 'Single', 'P004', 'FL202', 22000, '2018-08-25', NULL, '101'),
(100034, 'BR02', 'Hoseok', 'Jong', '(82) 808-9158', 'Cheonggu Building 3F. 13-20, Dosan-daero 16-gil. Gangnam-gu, Seoul 06040. South Korea.', '1994-02-13', 'M', 'HoseokJJ@gmail.com', 'I\'minlovewithyourbody', 'South Korea', 'Christianity', 'Single', 'P003', 'FL104', 16000, '2018-10-10', NULL, '101'),
(100035, 'BR01', 'Jimin', 'Park', '(82) 276-2154', 'Cheonggu Building 3F. 13-20, Dosan-daero 16-gil. Gangnam-gu, Seoul 06040. South Korea.', '1995-10-13', 'M', 'Jimin@gmail.com', 'WhenIseeyouagain', 'South Korea', 'Christianity', 'Single', 'P004', 'FL302', 20000, '2018-10-10', NULL, '100'),
(100036, 'BR01', 'Taehyung', 'Kim', '(82) 356-5515', 'Cheonggu Building 3F. 13-20, Dosan-daero 16-gil. Gangnam-gu, Seoul 06040. South Korea.', '1995-12-30', 'M', 'Taehyung@gmail.com', 'Letitgo_letitgo', 'South Korea', 'Christianity', 'Single', 'P004', 'FL303', 25000, '2019-02-01', NULL, '100'),
(100037, 'BR02', 'Jungkook', 'Jeon', '(82) 905-7331', 'Cheonggu Building 3F. 13-20, Dosan-daero 16-gil. Gangnam-gu, Seoul 06040. South Korea.', '1997-12-03', 'M', 'Jungkook@gmail.com', 'Idon\'tcare', 'South Korea', 'Christianity', 'Single', 'P003', 'FL105', 17000, '2019-02-01', NULL, '101'),
(100038, 'BR02', 'Victoria', 'Prachuabmoh', '(66) 243-5441', '662 Rama IV Road, Bang Rak, Bangkok,10500', '1995-06-24', 'F', 'Victoria.P@gmail.com', 'iloveyou_jungkook', 'Thai', 'Buddhism', 'Single', 'P004', 'FL303', 25000, '2019-04-03', NULL, '101'),
(100039, 'BR01', 'Angelica', 'Buri', '(66) 484-1063', '471/9 Chiang Mai-Lamphun Road, Wat Ket Subdistrict, Mueang District, Chiang Mai Province, 50000', '1990-05-31', 'F', 'Angelica@gmail.com', 'Allyouneedislove', 'Thai', 'Buddhism', 'Single', 'P003', 'FL105', 18000, '2019-04-03', NULL, '101'),
(100040, 'BR01', 'Genesis', 'Na Chiangmai', '(66) 866-9873', '999 Moo 6 Laemphopattana 1 Road, Sai Thai, Mueang Krabi District, Krabi 81000', '1989-12-12', 'F', 'Genesis.mai@gmail.com', 'Loveyourbelovedlikethereisnotomorrow', 'Thai', 'Buddhism', 'Single', 'P003', 'FL302', 20000, '2019-05-12', NULL, '101'),
(100044, 'BR03', 'A', 'B', '0815674238', '126 Pracha Uthit Rd, Bang Mot, Thung Khru, Bangkok 10140', '1998-07-23', 'F', 'AandB@mail.kmutt.ac.th', '9feea1ade2f9483949c81e826f72ff83', 'Australian', 'Islam', 'Single', 'P002', 'FL302', 15000, '2021-02-06', NULL, '100'),
(100047, 'BR03', 'Dog', 'Socute', '0658428852', '126 Pracha Uthit Rd, Bang Mot, Thung Khru, Bangkok 10140', '1998-05-20', 'M', 'catsocute@gmail.com', '', 'Australian', 'Islam', 'Married', 'P004', 'FL999', 30000, '2022-05-06', NULL, '100');

-- --------------------------------------------------------

--
-- Table structure for table `type_booking`
--

CREATE TABLE `type_booking` (
  `Partial_Type_Booking_ID` int(4) NOT NULL,
  `Partial_Type_Booking_Name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `type_booking`
--

INSERT INTO `type_booking` (`Partial_Type_Booking_ID`, `Partial_Type_Booking_Name`) VALUES
(1, 'Service_Spa'),
(2, 'Service_Car'),
(3, 'Service_Boat'),
(4, 'Service_Restaurant'),
(5, 'Deluxe Room'),
(6, 'Duo Room'),
(7, 'Suite Room'),
(8, 'Luxury sky Room');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int(11) NOT NULL,
  `FirstName_User` varchar(20) NOT NULL,
  `LastName_User` varchar(20) NOT NULL,
  `Phone_User` varchar(15) NOT NULL,
  `DOB_User` date NOT NULL,
  `Gender_User` enum('M','F') NOT NULL,
  `Address_User` text NOT NULL,
  `Email_User` varchar(255) NOT NULL,
  `Password_User` varchar(255) NOT NULL,
  `StartDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `Role` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `FirstName_User`, `LastName_User`, `Phone_User`, `DOB_User`, `Gender_User`, `Address_User`, `Email_User`, `Password_User`, `StartDate`, `Role`) VALUES
(7, 'Nirosesofia', 'Phamonpol', '0658428852', '2002-02-21', 'F', '126 Pracha Uthit Rd, Bang Mot, Thung Khru, Bangkok 10140', 'nirosesofia.384@gmail.com', 'd5b98be0e27babb287dbf828c1330495', '2022-05-14 09:58:24', 'user'),
(8, 'admin', 'hotel', '02-305-611', '2001-07-23', 'M', '277 หมู่ที่ 5 Muang Pattaya, Bang Lamung District ,Mueang Krabi', 'adminhotel@gmail.com', 'd7c2b2ec744c52b7966042c0339d6830', '2022-05-14 10:01:39', 'admin'),
(9, 'manager', 'hotel', '02-305-611', '1998-05-18', 'M', '277 หมู่ที่ 5 Muang Pattaya, Bang Lamung District ,Mueang Krabi', 'managerhotel@gmail.com', '57c634ab5d836558ca91a16327da57ca', '2022-05-14 10:01:44', 'manager'),
(10, 'Kirigaya', 'Kazuto', '012-345-6789', '2000-07-10', 'M', 'Shinjuku-ku, Tokyo 160-0022', 'kiritoza55Lnw@gmail.com', '0a7563eac1df6cdb4f593776fbaf8b6e', '2022-05-14 10:04:20', 'user'),
(11, 'Yuuki', 'Asuna', '055-155-5511', '1999-09-30', 'F', 'Chofu Ga Oka, Chofu-shi, Tokyo 182-0021', 'asunayuki@gmail.com', '3fc0a7acf087f549ac2b266baf94b8b1', '2022-05-14 10:04:56', 'user'),
(12, 'Nobi', 'Nobita', '033-444-5566', '0995-01-01', 'M', 'Fujimi-cho, Chofu-shi, Tokyo 182-0033', 'IloveGiant@hotmail.com', 'e4b88b7980d1ce1f3b999f581fe79160', '2022-05-14 10:05:38', 'user'),
(13, 'Gouda', 'Takeshi', '099-987-6543', '1994-04-08', 'M', 'Chuo, Edogawa-ku, Tokyo 132-0021', 'Giantthebest@hotmail.com', '0bfc047f6e9a9d819f57871bbeb1003c', '2022-05-14 10:06:14', 'user'),
(14, 'Midoriya', 'Izuku', '044-634-5876', '2001-07-15', 'M', 'Hane, Hamura-shi, Tokyo 205-0012', 'AllmightIdol@gmail.com', '7db2e79d5a397283c2bc27f0c60bdfff', '2022-05-14 10:06:50', 'user'),
(15, 'Uraraka', 'Ochako', '023-423-3111', '2001-12-27', 'F', 'Akutsu-cho, Ota-shi, Gunma 370-0402', 'Chokobanana@outlook.com', '69e504455c958edea3dc486ecb1ed9d2', '2022-05-14 10:07:23', 'user'),
(16, 'Mike', 'Miller', '018-246-3579', '1988-08-08', 'M', 'Betsupo, Tomioka-shi, Gunma 370-2342', 'MikeGE@outlook.com', 'd5e327a461f2d60f187af87111fee091', '2022-05-14 10:09:10', 'user'),
(17, 'Kamado', 'Tanjirou', '044-674-9753', '1990-07-14', 'M', 'Daimyoji, Ebino-shi, Miyazaki 889-4311', 'Kamadosun@gmail.com', 'd626ce58dafb5bf13879ccf96590bfae', '2022-05-14 10:09:48', 'user'),
(18, 'Zenitsu', 'Agatsuma', '039-485-6758', '1990-09-03', 'F', 'Bessho, Kurayoshi-shi, Tottori 682-0905', 'Nezukochan@hotmail.com', '0794f43f990d99dfd6946ed01b8a8503', '2022-05-14 10:10:24', 'user'),
(19, 'John', 'Yasen', '044-555-5555', '2002-08-23', 'F', 'Ecchu Machi, Kurayoshi-shi, Tottori 682-0865', 'John1tap@gmail.com', '851130ac99e35bb4166df99e01c0f677', '2022-05-14 10:11:07', 'user'),
(22, 'Nirosesofia', 'Phamonpol', '0658428852', '2002-02-21', 'F', '126 Pracha Uthit Rd, Bang Mot, Thung Khru, Bangkok 10140', 'nirosesofia.384@mail.kmutt.ac.th', 'd5b98be0e27babb287dbf828c1330495', '2022-05-16 06:20:12', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `workstation`
--

CREATE TABLE `workstation` (
  `WorkStationID` varchar(5) NOT NULL,
  `WorkStationName` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `workstation`
--

INSERT INTO `workstation` (`WorkStationID`, `WorkStationName`) VALUES
('FL101', 'Room zone 1 Floor'),
('FL102', 'Room zone 2 Floor'),
('FL103', 'Room zone 3 Floor'),
('FL104', 'Room zone 4 Floor'),
('FL105', 'Room zone 5 Floor'),
('FL201', 'Restaurant zone 1 Floor'),
('FL202', 'Restaurant zone 2 Floor'),
('FL301', 'Boat'),
('FL302', 'Spa'),
('FL303', 'Car'),
('FL555', 'Lobby'),
('FL999', 'Office');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_status_for_staff`
--
ALTER TABLE `data_status_for_staff`
  ADD PRIMARY KEY (`Status_Staff_ID`);

--
-- Indexes for table `data_status_of_booking`
--
ALTER TABLE `data_status_of_booking`
  ADD PRIMARY KEY (`Status_Booking_ID`);

--
-- Indexes for table `hotel`
--
ALTER TABLE `hotel`
  ADD PRIMARY KEY (`BranchHotel_ID`);

--
-- Indexes for table `list_booking`
--
ALTER TABLE `list_booking`
  ADD PRIMARY KEY (`Booking_ID`),
  ADD KEY `List_Booking_ibfk_1` (`Partial_Type_Booking_ID`),
  ADD KEY `List_Booking_ibfk_2` (`BranchHotel_ID`),
  ADD KEY `List_Booking_ibfk_3` (`Status_Booking_ID`);

--
-- Indexes for table `list_promotion`
--
ALTER TABLE `list_promotion`
  ADD PRIMARY KEY (`PromotionID`),
  ADD KEY `List_Promotion_ibfk_1` (`Booking_ID`);

--
-- Indexes for table `main_reference_number`
--
ALTER TABLE `main_reference_number`
  ADD PRIMARY KEY (`ReferenceNumber`),
  ADD KEY `Main_Reference_Number_ibfk_1` (`UserID`),
  ADD KEY `Main_Reference_Number_ibfk_2` (`PaymentMethod_ID`);

--
-- Indexes for table `partial_reference_number`
--
ALTER TABLE `partial_reference_number`
  ADD PRIMARY KEY (`Reference_PartialNumber`),
  ADD KEY `Partial_Reference_Number_ibfk_1` (`ReferenceNumber`),
  ADD KEY `Partial_Reference_Number_ibfk_2` (`Staff_ID`),
  ADD KEY `Booking_ID` (`Booking_ID`);

--
-- Indexes for table `payment_method`
--
ALTER TABLE `payment_method`
  ADD PRIMARY KEY (`PaymentMethod_ID`);

--
-- Indexes for table `position`
--
ALTER TABLE `position`
  ADD PRIMARY KEY (`PositionID`);

--
-- Indexes for table `staff_information`
--
ALTER TABLE `staff_information`
  ADD PRIMARY KEY (`Staff_ID`),
  ADD KEY `BranchHotel_ID` (`BranchHotel_ID`),
  ADD KEY `PositionID` (`PositionID`),
  ADD KEY `WorkStationID` (`WorkStationID`),
  ADD KEY `Status_Staff_ID` (`Status_Staff_ID`);

--
-- Indexes for table `type_booking`
--
ALTER TABLE `type_booking`
  ADD PRIMARY KEY (`Partial_Type_Booking_ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);

--
-- Indexes for table `workstation`
--
ALTER TABLE `workstation`
  ADD PRIMARY KEY (`WorkStationID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `list_booking`
--
ALTER TABLE `list_booking`
  MODIFY `Booking_ID` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `list_promotion`
--
ALTER TABLE `list_promotion`
  MODIFY `PromotionID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=171;

--
-- AUTO_INCREMENT for table `main_reference_number`
--
ALTER TABLE `main_reference_number`
  MODIFY `ReferenceNumber` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `partial_reference_number`
--
ALTER TABLE `partial_reference_number`
  MODIFY `Reference_PartialNumber` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;

--
-- AUTO_INCREMENT for table `staff_information`
--
ALTER TABLE `staff_information`
  MODIFY `Staff_ID` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100052;

--
-- AUTO_INCREMENT for table `type_booking`
--
ALTER TABLE `type_booking`
  MODIFY `Partial_Type_Booking_ID` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `list_booking`
--
ALTER TABLE `list_booking`
  ADD CONSTRAINT `List_Booking_ibfk_1` FOREIGN KEY (`Partial_Type_Booking_ID`) REFERENCES `type_booking` (`Partial_Type_Booking_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `List_Booking_ibfk_2` FOREIGN KEY (`BranchHotel_ID`) REFERENCES `hotel` (`BranchHotel_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `List_Booking_ibfk_3` FOREIGN KEY (`Status_Booking_ID`) REFERENCES `data_status_of_booking` (`Status_Booking_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `list_promotion`
--
ALTER TABLE `list_promotion`
  ADD CONSTRAINT `List_Promotion_ibfk_1` FOREIGN KEY (`Booking_ID`) REFERENCES `list_booking` (`Booking_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `partial_reference_number`
--
ALTER TABLE `partial_reference_number`
  ADD CONSTRAINT `Partial_Reference_Number_ibfk_1` FOREIGN KEY (`ReferenceNumber`) REFERENCES `main_reference_number` (`ReferenceNumber`),
  ADD CONSTRAINT `Partial_Reference_Number_ibfk_2` FOREIGN KEY (`Staff_ID`) REFERENCES `staff_information` (`Staff_ID`),
  ADD CONSTRAINT `Partial_Reference_Number_ibfk_3` FOREIGN KEY (`Booking_ID`) REFERENCES `list_booking` (`Booking_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
