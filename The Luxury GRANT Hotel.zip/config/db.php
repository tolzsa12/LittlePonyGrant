<?php
    $servername = "localhost";
    $username = "root";
    $password = "";

      $conn = mysqli_connect("localhost","root","","a4_GRANT");
        //check connection
      if(mysqli_connect_error()){
        echo "Failed to connect to MySQL: ".mysqli_connect_error();
      }
?>

