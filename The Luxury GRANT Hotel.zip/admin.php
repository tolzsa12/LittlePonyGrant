<?php 

    session_start();
    require_once 'config/db.php';
    if (!isset($_SESSION['admin_login'])) {
        $_SESSION['error'] = 'กรุณาเข้าสู่ระบบ!';
        header('location: signin1.php');
    }

    if (isset($_GET['logout'])) {
        session_destroy();
        unset($_SESSION['admin_login']);
        header('location: signin1.php');
    }

?>


<!DOCTYPE html><html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="style_HomePage1.css">
    <script src="https://kit.fontawesome.com/10654f14f2.js" crossorigin="anonymous"></script>

    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />

</head>

<body>

    <?php

        require_once 'config/db.php';
        //$query = "SELECT * FROM staff_information";
        $query = "SELECT * FROM list_promotion
        INNER JOIN list_booking ON list_booking.Booking_ID = list_promotion.Booking_ID ORDER BY PromotionID";

        $result = mysqli_query($conn,$query) or die("Error : $query".mysqli_error($query));
    ?> 

        
    <header class="header" id="navigation-menu">
        <div class="container">

            <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <a href="#" class="logo"> <img src="picture/logo.png" alt=""> </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav ">
                        <a class="nav-link h5 me-4" aria-current="page" href="CheckinRoom2.php">Check Room</a>
                        <a class="nav-link active h5 me-4" href="admin.php">Promotion</a>
                        <a class="nav-link h5 me-4" href="#">Booking</a>
                    </div>
                    <div class="navbar-right ms-auto">

                        <a href="logout.php" class="btn btn-danger">Logout</a>
                    </div>
                    </div>
                </div>
            </nav>
        </div>
  </header>  
  
  

  <!--------------header-------->
    <!--------------book-------------->
    <!--section คือการแบ่งส่วนกัน---->
    <div class="home" id="home">
        <div class="head_container">
        <div class="image">
            <img src="picture/home1.png" class="slide">
        </div>
        </div>
    </div>

    <?php
        require_once 'config/db.php';
        //$query = "SELECT * FROM staff_information";
        $query = "SELECT * FROM list_promotion
        INNER JOIN list_booking ON list_booking.Booking_ID = list_promotion.Booking_ID";

        $result = mysqli_query($conn,$query) or die("Error : $query".mysqli_error($query));
    ?> 

    <div class="main">
        <div class="container">
        <h1 class = "title"> Promotion </h1>
        <div class="taa">
        <table class="table" style = "width: 80%">
            <thead>
                <tr>
                <th>Promotion_ID</th>
                <th>BookingName</th>
                <th>Standardprice</th>
                <th>Promotionprice</th>
                <th>StartPromotion</th>
                <th>DuedatePromotion</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($result as $row){ ?>
                <tr>
                    <td><?php echo $row['PromotionID'];?></td>
                    <td><?php echo $row['Booking_Name'];?></td>
                    <td><?php echo $row['Standard_Price'];?></td>
                    <td><?php echo $row['PromotionPrice'];?></td>
                    <td><?php echo $row['StartPromotion'];?></td>
                    <td><?php echo $row['DuedatePromotion'];?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
        </div>
    </div>



    <style>
        :root {
            font-size: 100%;
            font-size: 16px;
            line-height: 1.5;
            --primary-blue: #1565D8;
            --second-yellow: #F9D100;
            --third-blue: #36C3C5;
        }
        
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Hind Vadodara';
            scroll-behavior: smooth;
            border-left: 0;
        }
        
        li {
            list-style: none;
        }
        
        a {
            text-decoration: none;
        }
        
        
        
        .head_container {
            max-width: 90%;
            margin: auto;
        }
        
        /*--------------header--------*/
        header {
            height: 100%;
            background-color: #fff;
            position: relative;
        }
        
        .logo img {
            width: 70px;
            margin-left: 20px;
            display: flex;
            align-items: center;
        }
        
        .cart{
            margin-right: 40px;
        }
        
        /*--------------header--------*/
        /*--------------home--------*/
        
        .home .image img {
            position: absolute;
            top: 0;
            left: 0;
            z-index: -1;
            width: 100%;
            height: 40%;
        }

        .main{
            margin-top: 20%;
            margin-left: 10%;
        }

        .main .title{
            margin-bottom: 2%;
            margin-left: 35%;
        }

        .table{
            margin-left: 5%;
        }
    </style>

</body>
</html>