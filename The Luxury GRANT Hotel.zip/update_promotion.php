<?php 
    require_once 'config/db.php';

    $PromotionID = $_GET["PromotionID"];

    //echo $Staff_ID;

    $query = "SELECT * FROM list_promotion WHERE PromotionID = $PromotionID";
    $result = mysqli_query($conn,$query) or die("Error : $query".mysqli_error($query));
    $row = mysqli_fetch_array($result);
?>


<!DOCTYPE html><html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Page</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" href="style_HomePage.css">
<script src="https://kit.fontawesome.com/10654f14f2.js" crossorigin="anonymous"></script>

<script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css" />
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />

</head>

<body>
    
<header class="header" id="navigation-menu">
    <div class="container">

        <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <a href="#" class="logo"> <img src="picture/logo.png" alt=""> </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav ">
                    <a class="nav-link" href="ManagerStaff.php">STAFF</a>
                    <a class="nav-link" href="manager.php">Uplode Data Staff</a>
                    <a class="nav-link active" href="ManagerPromotion.php">PROMOTION</a>
                    <a class="nav-link" href="dashboard.php">DASHBOARD</a>
                </div>
                <div class="navbar-right ms-auto">

                    <a href="logout.php" class="btn btn-danger">Logout</a>
                </div>
                </div>
            </div>
        </nav>
    </div>
</header>  

    <!--------------header-------->
    <!--------------book-------------->
    <!--section คือการแบ่งส่วนกัน---->
    <div class="home" id="home">
        <div class="head_container">
        <div class="image">
            <img src="picture/home1.png" class="slide">
        </div>
        </div>
    </div>
 
<section>

    <div class="contentBx">
        <div class="formBx">
            <h1>Update Promotion</h1>

            <form action="update_promotion_db.php" method="post">
                <input type="hidden" value = <?php echo $row['PromotionID']; ?> name = PromotionID>

                <?php 
                        if(isset($_SESSION['error'])) { ?>
                            <div class="alert alert-danger" role="alert">
                                <?php
                                    echo $_SESSION['error'];
                                    unset($_SESSION['error']);
                                ?>
                            </div>
                        <?php } ?>
                        <?php if(isset($_SESSION['success'])) { ?>
                            <div class="alert alert-success" role="alert">
                                <?php
                                    echo $_SESSION['success'];
                                    unset($_SESSION['success']);
                                ?>
                            </div>
                        <?php } ?>
                        <?php if(isset($_SESSION['warning'])) { ?>
                            <div class="alert alert-warning" role="alert">
                                <?php
                                    echo $_SESSION['warning'];
                                    unset($_SESSION['warning']);
                                ?>
                            </div>
                        <?php } 
                    ?>

                <div class="inputBx">
                    <label for="Booking_ID">Booking Name</label>
                    <input calss="Booking_ID" type="text" name="Booking_ID" placeholder="BookingID" require value = "<?php echo $row['Booking_ID']; ?>">
                </div>
                <div class="row">
                    <div class="inputBx">
                        <label for="Standard_Price">Standard price</label>
                        <input class="Standard_Price" type="number" name="Standard_Price" placeholder="Standard price" require value = "<?php echo $row['Standard_Price']; ?>"></input>
                    </div>
                    <div class="inputBx">
                        <label for="PromotionPrice">Promotion price</label>
                        <input class="PromotionPrice" type="number" name="PromotionPrice" placeholder="Promotion price" require value = "<?php echo $row['PromotionPrice']; ?>"></input>
                    </div>
                </div>
                
                <div class="row">
                    <div class="inputBx">
                        <label for="StartPromotion">Start Promotion</label>
                        <input class="StartPromotion" type="date" name="StartPromotion" require value = "<?php echo $row['StartPromotion']; ?>">
                    </div>
                    <div class="inputBx">
                        <label for="DuedatePromotion">Due date Promotion</label>
                        <input class="DuedatePromotion" type="date" name="DuedatePromotion" require value = "<?php echo $row['DuedatePromotion']; ?>">
                    </div>
                </div>
                <div class="inputBx">
                    <input type="submit" name="upload_promotion" value="Update Promotion">
                </div>
            </form>
        </div>
    </div>
</section>


<style>
    :root {
        font-size: 100%;
        font-size: 16px;
        line-height: 1.5;
        --primary-blue: #1565D8;
        --second-yellow: #F9D100;
        --third-blue: #36C3C5;
    }

    *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Hind Vadodara';
    }

    li {
        list-style: none;
    }

    a {
        text-decoration: none;
    }


    
    .head_container {
        max-width: 90%;
        margin: auto;
    }
    
    /*--------------header--------*/
    header {
        height: 100%;
        background-color: #fff;
        position: relative;
    }
    
    .logo img {
        width: 70px;
        margin-left: 20px;
        display: flex;
        align-items: center;
    }
    
    .cart{
        margin-right: 40px;
    }
    

    .home .image img {
            position: absolute;
            top: 0;
            left: 0;
            z-index: -1;
            width: 100%;
            height: 40%;
        }

        .main{
            margin-top: 20%;
            margin-left: 10%;
        }

    /*--------------header--------*/

    .contentBx{
        position: relative;
        width: 100%;
        height: 200vh;
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: -150px;
    }

    section .imgBx img{
        position: relative;
        width: 100%;
        height: 30vh;
        object-fit: cover;
        object-position: center;
        justify-content: center;
        align-items: center;
        display: flex;
    }

    section .contentBx .formBx h1{
        font-size: 1.5rem;
        font-weight: 700;
        color: black;
        margin-bottom: 50px;
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: -50px;
    }

    section .contentBx .formBx .inputBx input{
        width: 100%;
        padding: 10px 20px;
        outline: none;
        border: 1px solid #c4c4c4;
        letter-spacing: 1px;
        color: #313131;
        background: transparent;
        border-radius: 6px;
        margin-bottom: 1rem;
        font-size: 0.75rem;  
        font-weight: 400;
        margin-top: 0.5rem;
    }

    section .contentBx .formBx .row {
        width: 99.5%;
        margin-left: 3px;
    }

    .title-brance-hotel,
    .title-position_staff
    .title-workstation{
        margin-bottom: 0.5rem;
    }

    section .contentBx .formBx .inputBx input:focus{
        border: 2px solid #1565D8;
    }

    section .contentBx .formBx .inputBx{
        padding: 0em;
        margin-bottom: 0.5rem;
        font-size: 0.875rem;
        font-weight: 500;
        color: #313131;
        position: relative;
    }

    section .contentBx .formBx .inputBx input[type="submit"]
    {
        width: 100%;
        background: var(--second-yellow);
        color: rgb(255, 255, 255);
        font-weight: 700;
        border: none;
        outline: none;
        padding: 1rem;
        border-radius: 8px;
        font-size: 0.75rem;
        cursor: pointer;
        text-transform: uppercase;
        margin-top: 3rem;
    }

    section .contentBx .formBx .inputBx input[type="submit"]:hover{
        background: var(--primary-blue);
        cursor: pointer;
    }

    .row{
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .row .inputBx{
        flex-basis: 49%;
    }




    </style>